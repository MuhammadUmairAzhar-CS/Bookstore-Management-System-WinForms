namespace DL
{
    public static class BookRepository
    {
        private static void LogError(string context, Exception ex)
        {
            try
            {
                AppConfig.EnsureDirectoriesExist();
                string entry =
                    $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] [BookRepository.{context}] " +
                    $"{ex.GetType().Name}: {ex.Message}{Environment.NewLine}";
                File.AppendAllText(AppConfig.ErrorLogPath, entry);
            }
            catch { }
        }

        public static (List<BookRecord> Books, List<string> Warnings)
            LoadBooks(string filePath)
        {
            var books    = new List<BookRecord>();
            var warnings = new List<string>();

            try
            {
                AppConfig.EnsureDirectoriesExist();
                if (!File.Exists(filePath)) return (books, warnings);

                string[] lines = File.ReadAllLines(filePath);

                foreach ((string line, int idx) in lines.Select((l, i) => (l, i + 1)))
                {
                    if (string.IsNullOrWhiteSpace(line)) continue;

                    string[] parts = line.Split('|');
                    if (parts.Length != 4)
                    {
                        warnings.Add(
                            $"Line {idx} in '{Path.GetFileName(filePath)}' is corrupted " +
                            $"(expected 4 fields, got {parts.Length}) — skipped.");
                        continue;
                    }

                    var book = BookRecord.FromFileLine(line);
                    if (book is null)
                        warnings.Add($"Line {idx} could not be parsed — skipped.");
                    else
                        books.Add(book);
                }
            }
            catch (UnauthorizedAccessException ex)
            {
                LogError(nameof(LoadBooks), ex);
                warnings.Add("Permission denied reading book data.");
            }
            catch (IOException ex)
            {
                LogError(nameof(LoadBooks), ex);
                warnings.Add($"I/O error reading book file: {ex.Message}");
            }
            catch (Exception ex)
            {
                LogError(nameof(LoadBooks), ex);
                warnings.Add($"Unexpected error loading books: {ex.Message}");
            }

            return (books, warnings);
        }

        public static List<BookRecord> LoadAllBooks()
        {
            var all = new List<BookRecord>();
            string[] genrePaths =
            {
                AppConfig.ActionBooksPath,      // TODO: path to actionBooks.txt
                AppConfig.FictionBooksPath,     // TODO: path to fictionBooks.txt
                AppConfig.NonFictionBooksPath,  // TODO: path to nonFictionBooks.txt
                AppConfig.HorrorBooksPath,      // TODO: path to horrorBooks.txt
                AppConfig.MangaBooksPath        // TODO: path to mangaBooks.txt
            };

            foreach (string path in genrePaths)
                all.AddRange(LoadBooks(path).Books);

            return all;
        }

        public static FileResult SaveBooks(string filePath, List<BookRecord> books)
        {
            try
            {
                AppConfig.EnsureDirectoriesExist();

                string tmpPath = filePath + ".tmp";
                File.WriteAllLines(tmpPath, books.Select(b => b.ToFileLine()));

                if (File.Exists(filePath)) File.Delete(filePath);
                File.Move(tmpPath, filePath);

                return FileResult.Ok($"{books.Count} book(s) saved.");
            }
            catch (UnauthorizedAccessException ex)
            {
                LogError(nameof(SaveBooks), ex);
                return FileResult.Fail("Permission denied writing book data.");
            }
            catch (IOException ex)
            {
                LogError(nameof(SaveBooks), ex);
                return FileResult.Fail($"I/O error saving books: {ex.Message}");
            }
            catch (Exception ex)
            {
                LogError(nameof(SaveBooks), ex);
                return FileResult.Fail($"Unexpected error saving books: {ex.Message}");
            }
        }
    }
}

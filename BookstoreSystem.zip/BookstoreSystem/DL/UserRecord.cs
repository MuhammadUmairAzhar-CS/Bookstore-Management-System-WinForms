namespace DL
{
    public sealed class UserRecord
    {
        // ── Properties ────────────────────────────────────────────────────────
        public string Username     { get; set; } = string.Empty;
        public string PasswordHash { get; set; } = string.Empty;
        public string Email        { get; set; } = string.Empty;
        public string Role         { get; set; } = "User";

        // ── Constructors ──────────────────────────────────────────────────────
        public UserRecord() { }

        public UserRecord(string username, string passwordHash, string email, string role)
        {
            Username     = username;
            PasswordHash = passwordHash;
            Email        = email;
            Role         = role;
        }

        // ── Serialisation ─────────────────────────────────────────────────────
        public string ToFileLine() => $"{Username}|{PasswordHash}|{Email}|{Role}";

        public static UserRecord? FromFileLine(string line)
        {
            if (string.IsNullOrWhiteSpace(line)) return null;

            string[] parts = line.Split('|');
            if (parts.Length != 4) return null;

            if (parts.Any(p => string.IsNullOrWhiteSpace(p))) return null;

            return new UserRecord(
                parts[0].Trim(),
                parts[1].Trim(),
                parts[2].Trim(),
                parts[3].Trim());
        }
    }
}

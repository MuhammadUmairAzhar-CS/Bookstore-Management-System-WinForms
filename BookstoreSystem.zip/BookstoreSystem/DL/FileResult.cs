namespace DL
{

    public sealed class FileResult
    {
        public bool   Success { get; }
        public string Message { get; }

        private FileResult(bool success, string message)
        {
            Success = success;
            Message = message;
        }

        public static FileResult Ok(string message = "Operation completed.")
            => new(true,  message);

        public static FileResult Fail(string message)
            => new(false, message);
    }
}

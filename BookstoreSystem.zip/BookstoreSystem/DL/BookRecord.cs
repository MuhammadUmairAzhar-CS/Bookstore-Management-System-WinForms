namespace DL
{
    public sealed class BookRecord
    {
        public string  Title  { get; set; } = string.Empty;
        public string  Author { get; set; } = string.Empty;
        public decimal Price  { get; set; }
        public string  Genre  { get; set; } = string.Empty;

        public BookRecord() { }

        public BookRecord(string title, string author, decimal price, string genre)
        {
            Title  = title;
            Author = author;
            Price  = price;
            Genre  = genre;
        }

        public string ToFileLine() => $"{Title}|{Author}|{Price:F2}|{Genre}";

        public static BookRecord? FromFileLine(string line)
        {
            if (string.IsNullOrWhiteSpace(line)) {return null;}

            string[] parts = line.Split('|');
            if (parts.Length != 4) return null;

            // Price must be a valid decimal number
            if (!decimal.TryParse(parts[2].Trim(), out decimal price)) return null;

            return new BookRecord(
                parts[0].Trim(),
                parts[1].Trim(),
                price,
                parts[3].Trim());
        }

        public override string ToString() =>
            $"{Title} by {Author} — ${Price:F2} [{Genre}]";
    }
}

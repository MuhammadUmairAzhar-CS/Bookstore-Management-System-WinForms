namespace DL
{
    public static class AppConfig
    {
        private static readonly string BaseDir = @"C:\Users\mhdum\OneDrive\Desktop\File handeling";

        public static readonly string DataDir = Path.Combine(BaseDir, "Data");
        public static readonly string LogDir  = Path.Combine(BaseDir, "Logs");

        public static string UserFilePath  => Path.Combine(DataDir, "Userdetails.txt");

        public static string AdminFilePath => Path.Combine(DataDir, "Admindetails.txt");

        public static string MasterBooksPath => Path.Combine(DataDir, "Books.txt");

        public static string ActionBooksPath => Path.Combine(DataDir, "actionBooks.txt");

        public static string FictionBooksPath => Path.Combine(DataDir, "fictionBooks.txt");

        public static string NonFictionBooksPath => Path.Combine(DataDir, "nonFictionBooks.txt");

        public static string HorrorBooksPath => Path.Combine(DataDir, "horrorBooks.txt");

        public static string MangaBooksPath => Path.Combine(DataDir, "mangaBooks.txt");
        public static string PurchaseLogPath => Path.Combine(DataDir, "PurchaseHistory.txt");

        public static string ErrorLogPath => Path.Combine(LogDir, "errors.log");

        public static readonly string[] ValidGenres =
            { "Action", "Fiction", "NonFiction", "Horror", "Manga" };

        public static string GetGenreFilePath(string genre) => genre.ToLowerInvariant() switch
        {
            "action"     => ActionBooksPath,
            "fiction"    => FictionBooksPath,
            "nonfiction" => NonFictionBooksPath,
            "horror"     => HorrorBooksPath,
            "manga"      => MangaBooksPath,
            _            => MasterBooksPath   
        };
        public static void EnsureDirectoriesExist()
        {
            Directory.CreateDirectory(DataDir);
            Directory.CreateDirectory(LogDir);
        }

        public static void EnsureFilesExist()
        {
            string[] allFiles = {
        UserFilePath, AdminFilePath, MasterBooksPath, ActionBooksPath,
        FictionBooksPath, NonFictionBooksPath, HorrorBooksPath,
        MangaBooksPath, PurchaseLogPath, ErrorLogPath
    };

            foreach (string file in allFiles)
            {
                if (!File.Exists(file))
                {
                    File.Create(file).Close();
                }
            }
        }

    }
}

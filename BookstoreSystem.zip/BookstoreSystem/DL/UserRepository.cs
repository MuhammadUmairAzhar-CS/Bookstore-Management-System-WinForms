namespace DL
{
    public static class UserRepository
    {
        private static void LogError(string context, Exception ex)
        {
            try
            {
                AppConfig.EnsureDirectoriesExist();
                string entry =
                    $"[{DateTime.Now:yyyy-MM-dd HH:mm:ss}] [UserRepository.{context}] " +
                    $"{ex.GetType().Name}: {ex.Message}{Environment.NewLine}";

                File.AppendAllText(AppConfig.ErrorLogPath, entry);
            }
            catch { }
        }

        public static (List<UserRecord> Users, List<string> Warnings)
            LoadUsers(string filePath)
        {

            var users    = new List<UserRecord>();
            var warnings = new List<string>();

            try
            {
                AppConfig.EnsureDirectoriesExist();

                if (!File.Exists(filePath))
                    return (users, warnings);

                string[] lines = File.ReadAllLines(filePath);

                foreach ((string line, int idx) in lines.Select((l, i) => (l, i + 1)))
                {
                    if (string.IsNullOrWhiteSpace(line)) continue;

                    string[] parts = line.Split('|');
                    if (parts.Length != 4)
                    {
                        warnings.Add(
                            $"Line {idx} in '{Path.GetFileName(filePath)}' is corrupted " +
                            $"(expected 4 fields, got {parts.Length}) — skipped.");
                        continue;
                    }

                    var user = UserRecord.FromFileLine(line);
                    if (user is null)
                        warnings.Add($"Line {idx} could not be parsed — skipped.");
                    else
                        users.Add(user);
                }
            }
            catch (UnauthorizedAccessException ex)
            {
                LogError(nameof(LoadUsers), ex);
                warnings.Add("Permission denied reading user data. Try running as Administrator.");
            }
            catch (IOException ex)
            {
                LogError(nameof(LoadUsers), ex);
                warnings.Add($"I/O error reading user file: {ex.Message}");
            }
            catch (Exception ex)
            {
                LogError(nameof(LoadUsers), ex);
                warnings.Add($"Unexpected error loading users: {ex.Message}");
            }

            return (users, warnings);
        }
        public static FileResult SaveUsers(string filePath, List<UserRecord> users)
        {
            try
            {
                AppConfig.EnsureDirectoriesExist();

                // TODO: If you relocate account files, update AppConfig.DataDir.
                string tmpPath = filePath + ".tmp";
                File.WriteAllLines(tmpPath, users.Select(u => u.ToFileLine()));

                if (File.Exists(filePath)) File.Delete(filePath);
                File.Move(tmpPath, filePath);

                return FileResult.Ok($"{users.Count} user(s) saved successfully.");
            }
            catch (UnauthorizedAccessException ex)
            {
                LogError(nameof(SaveUsers), ex);
                return FileResult.Fail("Permission denied. Cannot write to user data file.");
            }
            catch (IOException ex)
            {
                LogError(nameof(SaveUsers), ex);
                return FileResult.Fail($"I/O error saving users: {ex.Message}");
            }
            catch (Exception ex)
            {
                LogError(nameof(SaveUsers), ex);
                return FileResult.Fail($"Unexpected error saving users: {ex.Message}");
            }
        }
    }
}

using DL;

namespace UI
{
    internal static class Program
    {
        [STAThread]
        static void Main()
        {
            AppConfig.EnsureDirectoriesExist();
            ApplicationConfiguration.Initialize();

            Application.ThreadException += (_, e) =>
                MessageBox.Show(
                    $"An unexpected error occurred:\n\n{e.Exception.Message}",
                    "Unexpected Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

            AppDomain.CurrentDomain.UnhandledException += (_, e) =>
                MessageBox.Show(
                    $"A fatal error occurred:\n\n{(e.ExceptionObject as Exception)?.Message}",
                    "Fatal Error",
                    MessageBoxButtons.OK, MessageBoxIcon.Error);

            Application.Run(new LoginForm());
        }
    }
}
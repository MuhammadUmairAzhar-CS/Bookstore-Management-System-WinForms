// [FILE PATH: BookstoreSystem3Tier/UI/DeleteBookForm.Designer.cs]
// FIXED: ClientSize so warning card at the bottom is never clipped.

namespace UI
{
    partial class DeleteBookForm
    {
        private System.ComponentModel.IContainer components = null;
        private Panel   pnlHeader;
        private Panel   pnlBody;
        private Label   lblFormTitle;
        private Label   lblSubtitle;
        private Label   lblInstruction;
        private TextBox txtBookTitle;
        private Button  btnSearch;
        private Panel   pnlFoundInfo;
        private Label   lblBookInfo;
        private Button  btnDelete;
        private Label   lblStatus;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            pnlHeader = new Panel();    pnlBody       = new Panel();
            lblFormTitle = new Label(); lblSubtitle   = new Label();
            lblInstruction = new Label(); txtBookTitle = new TextBox();
            btnSearch = new Button();   pnlFoundInfo  = new Panel();
            lblBookInfo = new Label();  btnDelete      = new Button();
            lblStatus = new Label();

            this.SuspendLayout();

            this.Text            = "Remove a Book — Admin";
            this.ClientSize      = new Size(580, 510);   // ← ClientSize
            this.StartPosition   = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox     = false;
            this.BackColor       = UITheme.Surface;
            this.Font            = UITheme.FontBase;

            // Header (0‒70)
            pnlHeader.Location  = new Point(0, 0);
            pnlHeader.Size      = new Size(580, 70);
            pnlHeader.BackColor = UITheme.Danger;

            var badge = UITheme.MakeBadge("ADMIN ONLY", Color.FromArgb(40, 0, 0, 0), Color.FromArgb(255, 210, 210));
            badge.Location = new Point(492, 16);

            lblFormTitle.Text = "Remove a Book";  lblFormTitle.Font = new Font("Segoe UI Semibold", 17F);
            lblFormTitle.ForeColor = Color.White; lblFormTitle.Location = new Point(22, 10); lblFormTitle.AutoSize = true;

            lblSubtitle.Text = "Search for the book first, then confirm deletion";
            lblSubtitle.Font = new Font("Segoe UI", 8.5F, FontStyle.Italic);
            lblSubtitle.ForeColor = Color.FromArgb(255, 190, 190); lblSubtitle.Location = new Point(22, 46); lblSubtitle.AutoSize = true;

            pnlHeader.Controls.AddRange(new Control[]
                { UITheme.MakeTopStripe(580, UITheme.Danger, 4), badge, lblFormTitle, lblSubtitle });

            // Body (70‒510) — 440 px of work area
            //   Positions inside pnlBody:
            //   Step 1 bar:    y=0    h=34
            //   Instruction:   y=46   h=22
            //   Search row:    y=76   h=36
            //   Found card:    y=126  h=54  (hidden until search)
            //   Step 2 bar:    y=192  h=34
            //   Delete btn:    y=238  h=48  bottom=286
            //   Status:        y=296  h=18
            //   Warning card:  y=322  h=96  bottom=418  (fits in 440)

            pnlBody.Location  = new Point(0, 70);
            pnlBody.Size      = new Size(580, 440);
            pnlBody.BackColor = Color.White;

            const int bx = 28, bw = 522;

            var step1Bar = new Panel { Location = new Point(0, 0), Size = new Size(580, 34), BackColor = UITheme.Surface };
            step1Bar.Controls.Add(new Label { Text = "STEP 1 — SEARCH FOR THE BOOK", Font = UITheme.FontLabel, ForeColor = UITheme.Primary, Location = new Point(bx, 10), AutoSize = true });

            lblInstruction.Text = "Enter the exact book title and click Search to verify it exists:";
            lblInstruction.Location = new Point(bx, 46); lblInstruction.Size = new Size(bw, 22);
            lblInstruction.AutoSize = false; lblInstruction.Font = UITheme.FontBase; lblInstruction.ForeColor = UITheme.TextSecondary;

            txtBookTitle.Location = new Point(bx, 76);   txtBookTitle.Size = new Size(390, 36);
            txtBookTitle.Font = UITheme.FontBase;         txtBookTitle.BorderStyle = BorderStyle.FixedSingle;
            txtBookTitle.BackColor = UITheme.Surface;     txtBookTitle.ForeColor = UITheme.TextPrimary;
            txtBookTitle.Name = "txtBookTitle";

            btnSearch.Text = "Search";  btnSearch.Location = new Point(bx + 400, 76); btnSearch.Size = new Size(120, 36);
            btnSearch.Click += btnSearch_Click;
            UITheme.StyleButton(btnSearch, UITheme.Primary, UITheme.PrimaryLight, font: UITheme.FontBtnSmall);

            // Found card (shown after successful search)
            pnlFoundInfo.Location = new Point(bx, 126); pnlFoundInfo.Size = new Size(bw, 54);
            pnlFoundInfo.BackColor = UITheme.SuccessLight; pnlFoundInfo.Visible = false;
            var infoBorder = new Panel { Location = new Point(0, 0), Size = new Size(4, 54), BackColor = UITheme.Success };
            var foundHead  = new Label { Text = "BOOK FOUND", Font = UITheme.FontLabel, ForeColor = UITheme.Success, Location = new Point(14, 8), AutoSize = true };
            lblBookInfo.Text = string.Empty; lblBookInfo.Location = new Point(14, 26);
            lblBookInfo.Size = new Size(bw - 22, 20); lblBookInfo.AutoSize = false;
            lblBookInfo.Font = UITheme.FontBase; lblBookInfo.ForeColor = UITheme.TextPrimary; lblBookInfo.Name = "lblBookInfo";
            pnlFoundInfo.Controls.AddRange(new Control[] { infoBorder, foundHead, lblBookInfo });

            var step2Bar = new Panel { Location = new Point(0, 192), Size = new Size(580, 34), BackColor = UITheme.Surface };
            step2Bar.Controls.Add(new Label { Text = "STEP 2 — CONFIRM PERMANENT DELETION", Font = UITheme.FontLabel, ForeColor = UITheme.Danger, Location = new Point(bx, 10), AutoSize = true });

            btnDelete.Text = "Delete This Book Permanently"; btnDelete.Location = new Point(bx, 238); btnDelete.Size = new Size(bw, 48);
            btnDelete.Enabled = false; btnDelete.Click += btnDelete_Click;
            UITheme.StyleButton(btnDelete, UITheme.Danger, Color.FromArgb(185, 28, 28), font: new Font("Segoe UI Semibold", 10.5F));

            lblStatus.Text = string.Empty; lblStatus.Location = new Point(bx, 296); lblStatus.Size = new Size(bw, 18);
            lblStatus.AutoSize = false; lblStatus.Font = UITheme.FontHint; lblStatus.ForeColor = UITheme.TextMuted; lblStatus.Name = "lblStatus";

            var warn = UITheme.MakeInfoCard(bx, 322, bw, 96,
                "WHAT GETS DELETED?",
                "The book is permanently removed from its genre catalogue and the master book list.\r\n\r\nThis action cannot be undone — always search and verify the correct title first.",
                UITheme.Danger, UITheme.DangerLight);

            pnlBody.Controls.AddRange(new Control[]
            {
                step1Bar, lblInstruction, txtBookTitle, btnSearch,
                pnlFoundInfo, step2Bar, btnDelete, lblStatus, warn
            });

            this.Controls.AddRange(new Control[] { pnlHeader, pnlBody });
            this.ResumeLayout(false);
        }
    }
}

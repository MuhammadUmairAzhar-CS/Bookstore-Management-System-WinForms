// [FILE PATH: BookstoreSystem3Tier/UI/AddBookForm.cs]
using BL.Services;
using DL;

namespace UI
{
    public partial class AddBookForm : Form
    {
        public AddBookForm() => InitializeComponent();

        private void btnSave_Click(object sender, EventArgs e)
        {
            string title     = txtTitle.Text.Trim();
            string author    = txtAuthor.Text.Trim();
            string priceText = txtPrice.Text.Trim();
            string genre     = cmbGenre.SelectedItem?.ToString() ?? string.Empty;

            if (!decimal.TryParse(priceText, out decimal price))
            {
                ShowWarning("Price must be a valid number (e.g. 12.99).");
                txtPrice.Focus();
                return;
            }

            var book   = new BookRecord(title, author, price, genre);
            var result = BookService.AddBook(book);

            if (!result.Success)
            {
                ShowWarning(result.Message);
                return;
            }

            SetStatus($"Added: \"{title}\" to {genre}", UITheme.Success);
            ShowInfo($"Book \"{title}\" was added to the {genre} catalogue successfully.");
            ClearForm();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            ClearForm();
            SetStatus(string.Empty, UITheme.TextMuted);
        }

        private void ClearForm()
        {
            txtTitle.Clear();
            txtAuthor.Clear();
            txtPrice.Clear();
            cmbGenre.SelectedIndex = 0;
            txtTitle.Focus();
        }

        private void SetStatus(string msg, Color color)
        {
            lblStatus.Text      = msg;
            lblStatus.ForeColor = color;
        }

        private void txtPrice_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '.' && e.KeyChar != '\b')
                e.Handled = true;
        }

        private static void ShowWarning(string m) =>
            MessageBox.Show(m, "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);

        private static void ShowInfo(string m) =>
            MessageBox.Show(m, "Book Added Successfully", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
}

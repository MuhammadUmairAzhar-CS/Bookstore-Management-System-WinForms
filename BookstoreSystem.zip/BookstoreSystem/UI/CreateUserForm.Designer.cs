// [FILE PATH: BookstoreSystem3Tier/UI/CreateUserForm.Designer.cs]
// ─────────────────────────────────────────────────────────────────────────────
// IMPROVED: Admin-side account creation form
//   Blue header with ADMIN ONLY badge
//   5 fields: Username, Password (+toggle), Confirm Password (+toggle), Email, Role
//   Status label shows success/failure inline
//   ClientSize used for exact layout
// ─────────────────────────────────────────────────────────────────────────────

namespace UI
{
    partial class CreateUserForm
    {
        private System.ComponentModel.IContainer components = null;

        private Panel    pnlHeader;
        private Label    lblFormTitle;
        private Label    lblSubtitle;
        private Panel    pnlBody;
        private Label    lblUsername;
        private TextBox  txtUsername;
        private Label    lblPassword;
        private TextBox  txtPassword;
        private Button   btnTogglePwd;
        private Label    lblPasswordHint;
        private Label    lblConfirmPassword;
        private TextBox  txtConfirmPassword;
        private Button   btnToggleConfirm;
        private Label    lblEmail;
        private TextBox  txtEmail;
        private Label    lblRole;
        private ComboBox cmbRole;
        private Button   btnCreate;
        private Button   btnClearAll;
        private Button   btnCancel;
        private Label    lblStatus;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components       = new System.ComponentModel.Container();
            pnlHeader             = new Panel();
            lblFormTitle          = new Label();
            lblSubtitle           = new Label();
            pnlBody               = new Panel();
            lblUsername           = new Label();
            txtUsername           = new TextBox();
            lblPassword           = new Label();
            txtPassword           = new TextBox();
            btnTogglePwd          = new Button();
            lblPasswordHint       = new Label();
            lblConfirmPassword    = new Label();
            txtConfirmPassword    = new TextBox();
            btnToggleConfirm      = new Button();
            lblEmail              = new Label();
            txtEmail              = new TextBox();
            lblRole               = new Label();
            cmbRole               = new ComboBox();
            btnCreate             = new Button();
            btnClearAll           = new Button();
            btnCancel             = new Button();
            lblStatus             = new Label();

            this.SuspendLayout();

            // ── Form ───────────────────────────────────────────────────────────
            this.Text            = "Create New Account — Admin";
            this.ClientSize      = new Size(500, 590);
            this.StartPosition   = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox     = false;
            this.BackColor       = UITheme.Surface;
            this.Font            = UITheme.FontBase;

            // ── Header (0‒70) ─────────────────────────────────────────────────
            pnlHeader.Location  = new Point(0, 0);
            pnlHeader.Size      = new Size(500, 70);
            pnlHeader.BackColor = UITheme.AdminColor;
            pnlHeader.Controls.Add(UITheme.MakeTopStripe(500, UITheme.Accent, 4));

            var badge = UITheme.MakeBadge("ADMIN ONLY",
                Color.FromArgb(40, 0, 0, 0), Color.FromArgb(255, 240, 190));
            badge.Location = new Point(412, 16);

            lblFormTitle.Text      = "Create New Account";
            lblFormTitle.Font      = new Font("Segoe UI Semibold", 17F);
            lblFormTitle.ForeColor = Color.White;
            lblFormTitle.Location  = new Point(22, 10);
            lblFormTitle.AutoSize  = true;

            lblSubtitle.Text      = "Fill in all fields to create a new user or admin account";
            lblSubtitle.Font      = new Font("Segoe UI", 8.5F, FontStyle.Italic);
            lblSubtitle.ForeColor = Color.FromArgb(180, 220, 255);
            lblSubtitle.Location  = new Point(22, 46);
            lblSubtitle.AutoSize  = true;

            pnlHeader.Controls.AddRange(new Control[] { badge, lblFormTitle, lblSubtitle });

            // ── Body (70‒590) — 520 px work area ─────────────────────────────
            // Explicit y positions (relative to pnlBody):
            //   [G1] Username:         label=20  input=40  bottom=76
            //   [G2] Password:         label=90  input=110 bottom=146  hint=150 bottom=166
            //   [G3] Confirm Pwd:      label=178 input=198 bottom=234
            //   [G4] Email:            label=248 input=268 bottom=304
            //   [G5] Role:             label=318 combo=338 bottom=374
            //   Divider:               y=390
            //   Create button:         y=400 h=48 bottom=448
            //   Clear / Cancel row:    y=460
            //   Status label:          y=498

            pnlBody.Location  = new Point(0, 70);
            pnlBody.Size      = new Size(500, 520);
            pnlBody.BackColor = Color.White;

            const int bx = 28, bw = 444;

            // [G1] Username
            FL(lblUsername, "USERNAME", bx, 20);
            TX(txtUsername, "txtUsername", bx, 40, bw);

            // [G2] Password
            FL(lblPassword, "PASSWORD", bx, 90);
            TX(txtPassword, "txtPassword", bx, 110, bw - 82, pwd: true);
            TB(btnTogglePwd, "Show", bx + bw - 76, 110);
            btnTogglePwd.Click += btnTogglePwd_Click;

            lblPasswordHint.Text      = "Minimum 8 characters — include a number or symbol";
            lblPasswordHint.Location  = new Point(bx, 150);
            lblPasswordHint.Size      = new Size(bw, 16);
            lblPasswordHint.AutoSize  = false;
            lblPasswordHint.Font      = new Font("Segoe UI", 8F, FontStyle.Italic);
            lblPasswordHint.ForeColor = UITheme.TextMuted;

            // [G3] Confirm Password
            FL(lblConfirmPassword, "CONFIRM PASSWORD", bx, 178);
            TX(txtConfirmPassword, "txtConfirmPassword", bx, 198, bw - 82, pwd: true);
            TB(btnToggleConfirm, "Show", bx + bw - 76, 198);
            btnToggleConfirm.Click += btnToggleConfirm_Click;

            // [G4] Email
            FL(lblEmail, "EMAIL ADDRESS", bx, 248);
            TX(txtEmail, "txtEmail", bx, 268, bw);

            // [G5] Role
            FL(lblRole, "ACCOUNT TYPE", bx, 318);
            cmbRole.Location      = new Point(bx, 338);
            cmbRole.Size          = new Size(bw, 36);
            cmbRole.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbRole.Items.AddRange(new object[] { "User", "Admin" });
            cmbRole.SelectedIndex = 0;
            cmbRole.Font          = UITheme.FontBase;
            cmbRole.FlatStyle     = FlatStyle.Flat;
            cmbRole.BackColor     = UITheme.Surface;
            cmbRole.Name          = "cmbRole";

            pnlBody.Controls.Add(UITheme.MakeDivider(bx, 390, bw));

            // Create Account button
            btnCreate.Text     = "Create Account";
            btnCreate.Location = new Point(bx, 400);
            btnCreate.Size     = new Size(bw, 48);
            btnCreate.Click   += btnCreate_Click;
            UITheme.StyleButton(btnCreate, UITheme.AdminColor,
                Color.FromArgb(109, 40, 217),
                font: new Font("Segoe UI Semibold", 11F));

            // Clear All + Cancel row
            btnClearAll.Text     = "Clear All Fields";
            btnClearAll.Location = new Point(bx, 460);
            btnClearAll.Size     = new Size(214, 34);
            btnClearAll.Click   += btnClearAll_Click;
            UITheme.StyleOutlineButton(btnClearAll, UITheme.TextSecondary);

            btnCancel.Text     = "Close / Done";
            btnCancel.Location = new Point(bx + 230, 460);
            btnCancel.Size     = new Size(214, 34);
            btnCancel.Click   += btnCancel_Click;
            UITheme.StyleOutlineButton(btnCancel, UITheme.TextSecondary);

            // Status label
            lblStatus.Text      = string.Empty;
            lblStatus.Location  = new Point(bx, 506);
            lblStatus.Size      = new Size(bw, 18);
            lblStatus.AutoSize  = false;
            lblStatus.Font      = new Font("Segoe UI", 9F, FontStyle.Italic);
            lblStatus.ForeColor = UITheme.Success;
            lblStatus.Name      = "lblStatus";

            pnlBody.Controls.AddRange(new Control[]
            {
                lblUsername,        txtUsername,
                lblPassword,        txtPassword,        btnTogglePwd,   lblPasswordHint,
                lblConfirmPassword, txtConfirmPassword, btnToggleConfirm,
                lblEmail,           txtEmail,
                lblRole,            cmbRole,
                btnCreate, btnClearAll, btnCancel, lblStatus
            });

            this.Controls.AddRange(new Control[] { pnlHeader, pnlBody });
            this.ResumeLayout(false);
        }

        private static void FL(Label l, string t, int x, int y)
        { l.Text = t; l.Font = UITheme.FontLabel; l.ForeColor = UITheme.TextSecondary; l.Location = new Point(x, y); l.AutoSize = true; }

        private static void TX(TextBox t, string n, int x, int y, int w, bool pwd = false)
        { t.Name = n; t.Location = new Point(x, y); t.Size = new Size(w, 36); t.Font = UITheme.FontBase; t.BorderStyle = BorderStyle.FixedSingle; t.BackColor = UITheme.Surface; t.ForeColor = UITheme.TextPrimary; if (pwd) t.UseSystemPasswordChar = true; }

        private static void TB(Button btn, string text, int x, int y)
        { btn.Text = text; btn.Location = new Point(x, y); btn.Size = new Size(76, 36); btn.Cursor = Cursors.Hand; btn.FlatStyle = FlatStyle.Flat; btn.BackColor = UITheme.Surface; btn.ForeColor = UITheme.Primary; btn.Font = new Font("Segoe UI Semibold", 8.5F); btn.FlatAppearance.BorderColor = UITheme.Border; btn.FlatAppearance.BorderSize = 1; btn.FlatAppearance.MouseOverBackColor = UITheme.PrimaryPale; }
    }
}

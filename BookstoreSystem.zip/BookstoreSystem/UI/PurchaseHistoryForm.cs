// [FILE PATH: BookstoreSystem3Tier/UI/PurchaseHistoryForm.cs]
// ─────────────────────────────────────────────────────────────────────────────
// UI LAYER — Purchase History Form
// Displays all purchase records from Data/PurchaseHistory.txt
// ─────────────────────────────────────────────────────────────────────────────

using BL.Services;

namespace UI
{
    public partial class PurchaseHistoryForm : Form
    {
        public PurchaseHistoryForm()
        {
            InitializeComponent();
            LoadHistory();
        }

        private void LoadHistory()
        {
            var records = BookService.GetPurchaseHistory();

            dgvHistory.Rows.Clear();
            decimal grandTotal = 0m;

            foreach (var r in records)
            {
                dgvHistory.Rows.Add(
                    r.When.ToString("yyyy-MM-dd HH:mm"),
                    r.User,
                    r.Title,
                    r.Qty,
                    $"${r.Unit:F2}",
                    $"${r.Total:F2}");
                grandTotal += r.Total;
            }

            lblCount.Text      = $"  {records.Count} transaction(s)";
            lblGrandTotal.Text = $"${grandTotal:F2}";
        }

        private void btnRefresh_Click(object sender, EventArgs e) => LoadHistory();
    }
}

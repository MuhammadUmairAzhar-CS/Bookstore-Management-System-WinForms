// [FILE PATH: BookstoreSystem3Tier/UI/DashboardForm.cs]
// ─────────────────────────────────────────────────────────────────────────────
// UI LAYER — Dashboard Form (code-behind)
// Role-based layout:
//   User  → single-column menu (browse, buy, history, sign out)
//   Admin → two-column menu (left: browse/history/sign-out;
//                             right: add/delete books + user management)
//
// CHANGED: Admins can NO LONGER purchase books (removed from admin layout).
//          ADDED: Manage User Accounts and Create New User Account for admins.
// ─────────────────────────────────────────────────────────────────────────────

using DL;

namespace UI
{
    public partial class DashboardForm : Form
    {
        private readonly UserRecord _currentUser;

        public DashboardForm(UserRecord user)
        {
            _currentUser = user;
            InitializeComponent();

            lblWelcomeName.Text = $"Hello, {_currentUser.Username}";
            lblRoleBadge.Text   = _currentUser.Role.ToUpper();
            lblRoleBadge.BackColor = _currentUser.Role == "Admin"
                ? UITheme.AdminColor
                : UITheme.Primary;

            bool isAdmin = _currentUser.Role == "Admin";
            pnlUserLayout.Visible  = !isAdmin;
            pnlAdminLayout.Visible = isAdmin;
        }

        // ── Shared actions (available to both roles) ──────────────────────────

        private void btnViewBooks_Click(object sender, EventArgs e)
        {
            using var f = new ViewBooksForm();
            f.ShowDialog(this);
        }

        private void btnHistory_Click(object sender, EventArgs e)
        {
            using var f = new PurchaseHistoryForm();
            f.ShowDialog(this);
        }

        private void btnLogout_Click(object sender, EventArgs e)
        {
            var answer = MessageBox.Show(
                "Are you sure you want to sign out?",
                "Confirm Sign Out",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (answer == DialogResult.Yes)
                this.Close();
        }

        // ── User-only actions ─────────────────────────────────────────────────

        /// <summary>
        /// Regular users can purchase books.
        /// Admins manage inventory — they do NOT have a Buy button.
        /// </summary>
        private void btnBuyBook_Click(object sender, EventArgs e)
        {
            using var f = new BuyBookForm(_currentUser);
            f.ShowDialog(this);
        }

        // ── Admin-only catalogue actions ──────────────────────────────────────

        private void btnAddBook_Click(object sender, EventArgs e)
        {
            using var f = new AddBookForm();
            f.ShowDialog(this);
        }

        private void btnDeleteBook_Click(object sender, EventArgs e)
        {
            using var f = new DeleteBookForm();
            f.ShowDialog(this);
        }

        // ── Admin-only user management actions ────────────────────────────────

        /// <summary>
        /// Opens the full user management panel.
        /// Admins can view all accounts, inspect per-user purchase history,
        /// delete accounts, and jump to the Create Account form.
        /// </summary>
        private void btnManageUsers_Click(object sender, EventArgs e)
        {
            using var f = new ManageUsersForm();
            f.ShowDialog(this);
        }

        /// <summary>
        /// Opens the Create Account dialog directly from the dashboard.
        /// Also reachable via the "+ Create New User" button inside ManageUsersForm.
        /// </summary>
        private void btnCreateUser_Click(object sender, EventArgs e)
        {
            using var f = new CreateUserForm();
            f.ShowDialog(this);
        }
    }
}

// [FILE PATH: BookstoreSystem3Tier/UI/DeleteBookForm.cs]
using BL.Services;

namespace UI
{
    public partial class DeleteBookForm : Form
    {
        public DeleteBookForm() => InitializeComponent();

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string title = txtBookTitle.Text.Trim();
            if (string.IsNullOrWhiteSpace(title))
            {
                ShowWarning("Please enter a book title to search.");
                return;
            }

            var book = BookService.FindBook(title);
            if (book is null)
            {
                SetInfo($"No book found with the title \"{title}\".", UITheme.Danger);
                btnDelete.Enabled = false;
                return;
            }

            SetInfo(
                $"Found:  {book.Title}   |   {book.Author}   |   ${book.Price:F2}   |   {book.Genre}",
                UITheme.Success);
            btnDelete.Enabled = true;
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            string title   = txtBookTitle.Text.Trim();
            var    confirm = MessageBox.Show(
                $"Are you sure you want to permanently delete:\n\n\"{title}\"\n\nThis action cannot be undone.",
                "Confirm Deletion",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (confirm != DialogResult.Yes) return;

            var result = BookService.DeleteBook(title);
            if (!result.Success)
            {
                ShowError(result.Message);
                return;
            }

            ShowInfo(result.Message);
            lblStatus.Text      = $"Last deleted: \"{title}\"";
            lblStatus.ForeColor = UITheme.TextSecondary;
            txtBookTitle.Clear();
            SetInfo(string.Empty, UITheme.TextMuted);
            btnDelete.Enabled = false;
        }

        private void SetInfo(string msg, Color color)
        {
            pnlFoundInfo.Visible  = !string.IsNullOrEmpty(msg);
            lblBookInfo.Text      = msg;
            lblBookInfo.ForeColor = color;
        }

        private static void ShowWarning(string m) =>
            MessageBox.Show(m, "Validation Error", MessageBoxButtons.OK, MessageBoxIcon.Warning);

        private static void ShowError(string m) =>
            MessageBox.Show(m, "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);

        private static void ShowInfo(string m) =>
            MessageBox.Show(m, "Book Deleted", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
}

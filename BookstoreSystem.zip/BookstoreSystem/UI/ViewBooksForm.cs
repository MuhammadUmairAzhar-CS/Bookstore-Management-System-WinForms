// [FILE PATH: BookstoreSystem3Tier/UI/ViewBooksForm.cs]
using BL.Services;

namespace UI
{
    public partial class ViewBooksForm : Form
    {
        public ViewBooksForm()
        {
            InitializeComponent();
            LoadBooks();
        }

        private void LoadBooks()
        {
            string genre  = cmbGenreFilter.SelectedItem?.ToString() ?? "All Genres";
            string search = txtSearch.Text.Trim().ToLowerInvariant();

            List<DL.BookRecord> books;
            List<string>        warnings;

            if (genre == "All Genres")
            {
                books    = BookService.GetAllBooks();
                warnings = new List<string>();
            }
            else
            {
                (books, warnings) = BookService.GetBooksByGenre(genre);
            }

            if (warnings.Count > 0)
            {
                lblStatus.Text      = $"  {warnings.Count} corrupted record(s) were skipped.";
                lblStatus.ForeColor = UITheme.Warning;
            }
            else
            {
                lblStatus.Text = string.Empty;
            }

            if (!string.IsNullOrEmpty(search))
                books = books
                    .Where(b =>
                        b.Title.ToLowerInvariant().Contains(search) ||
                        b.Author.ToLowerInvariant().Contains(search))
                    .ToList();

            dgvBooks.Rows.Clear();
            foreach (var b in books)
                dgvBooks.Rows.Add(b.Title, b.Author, $"${b.Price:F2}", b.Genre);

            lblCount.Text = $"  {books.Count} book(s) found";
        }

        private void cmbGenreFilter_SelectedIndexChanged(object sender, EventArgs e) => LoadBooks();
        private void txtSearch_TextChanged(object sender, EventArgs e)               => LoadBooks();
        private void btnRefresh_Click(object sender, EventArgs e)                    => LoadBooks();
    }
}

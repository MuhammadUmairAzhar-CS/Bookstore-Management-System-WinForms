// [FILE PATH: BookstoreSystem3Tier/UI/PurchaseHistoryForm.Designer.cs]
// FIXED: ClientSize + datagrid anchored inside a panel so footer never clips.
//   header(72) + toolbar(52) + grid panel(476) + footer(50) = 650 px
//   (dgvHistory is inside a panel, not placed directly on the form at y=136)

namespace UI
{
    partial class PurchaseHistoryForm
    {
        private System.ComponentModel.IContainer components = null;
        private Panel        pnlHeader;
        private Label        lblFormTitle;
        private Panel        pnlToolbar;
        private Button       btnRefresh;
        private Panel        pnlGridWrap;
        private DataGridView dgvHistory;
        private Panel        pnlFooter;
        private Label        lblCount;
        private Label        lblGrandTotal;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            pnlHeader    = new Panel();    lblFormTitle  = new Label();
            pnlToolbar   = new Panel();    btnRefresh    = new Button();
            pnlGridWrap  = new Panel();    dgvHistory    = new DataGridView();
            pnlFooter    = new Panel();    lblCount      = new Label();
            lblGrandTotal = new Label();

            this.SuspendLayout();

            this.Text            = "Transaction History";
            this.ClientSize      = new Size(980, 650);   // ← ClientSize
            this.StartPosition   = FormStartPosition.CenterParent;
            this.BackColor       = UITheme.Surface;
            this.Font            = UITheme.FontBase;

            // Header (0‒72)
            pnlHeader.Location  = new Point(0, 0);
            pnlHeader.Size      = new Size(980, 72);
            pnlHeader.BackColor = UITheme.PrimaryDark;
            pnlHeader.Controls.Add(UITheme.MakeTopStripe(980, UITheme.Primary, 4));

            lblFormTitle.Text = "Transaction History"; lblFormTitle.Font = new Font("Segoe UI Semibold", 17F);
            lblFormTitle.ForeColor = Color.White; lblFormTitle.Location = new Point(22, 10); lblFormTitle.AutoSize = true;

            pnlHeader.Controls.Add(new Label
            {
                Text = "A complete audit log of every confirmed purchase \u2014 oldest entries first",
                Font = new Font("Segoe UI", 8.5F, FontStyle.Italic),
                ForeColor = Color.FromArgb(140, 185, 230),
                Location = new Point(22, 46), AutoSize = true
            });
            pnlHeader.Controls.Add(lblFormTitle);

            // Toolbar (72‒124)
            pnlToolbar.Location  = new Point(0, 72);
            pnlToolbar.Size      = new Size(980, 52);
            pnlToolbar.BackColor = Color.White;
            pnlToolbar.Controls.Add(UITheme.MakeDivider(0, 51, 980));
            pnlToolbar.Controls.Add(new Label
            {
                Text = "Showing all purchase records \u2014 sorted oldest to newest",
                Font = new Font("Segoe UI", 9F), ForeColor = UITheme.TextSecondary,
                Location = new Point(18, 17), AutoSize = true
            });

            btnRefresh.Text = "Refresh Records"; btnRefresh.Location = new Point(838, 11); btnRefresh.Size = new Size(120, 32);
            btnRefresh.Click += btnRefresh_Click;
            UITheme.StyleButton(btnRefresh, UITheme.Primary, UITheme.PrimaryLight, font: UITheme.FontBtnSmall);
            pnlToolbar.Controls.Add(btnRefresh);

            // Grid wrap panel (124‒600)  height = 476
            pnlGridWrap.Location  = new Point(0, 124);
            pnlGridWrap.Size      = new Size(980, 476);
            pnlGridWrap.BackColor = Color.White;

            dgvHistory.Location = new Point(14, 12);
            dgvHistory.Size     = new Size(952, 452);
            dgvHistory.Name     = "dgvHistory";
            UITheme.StyleGrid(dgvHistory);

            dgvHistory.Columns.Add("colDate",  "Date & Time");
            dgvHistory.Columns.Add("colUser",  "Customer");
            dgvHistory.Columns.Add("colTitle", "Book Title");
            dgvHistory.Columns.Add("colQty",   "Qty");
            dgvHistory.Columns.Add("colUnit",  "Unit Price");
            dgvHistory.Columns.Add("colTotal", "Total");

            dgvHistory.Columns["colDate"]!.Width  = 148;
            dgvHistory.Columns["colUser"]!.Width  = 130;
            dgvHistory.Columns["colQty"]!.Width   = 54;
            dgvHistory.Columns["colUnit"]!.Width  = 96;
            dgvHistory.Columns["colTotal"]!.Width = 96;
            dgvHistory.Columns["colUnit"]!.DefaultCellStyle.Alignment  = DataGridViewContentAlignment.MiddleRight;
            dgvHistory.Columns["colTotal"]!.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvHistory.Columns["colQty"]!.DefaultCellStyle.Alignment   = DataGridViewContentAlignment.MiddleCenter;

            pnlGridWrap.Controls.Add(dgvHistory);

            // Footer (600‒650)
            pnlFooter.Location  = new Point(0, 600);
            pnlFooter.Size      = new Size(980, 50);
            pnlFooter.BackColor = Color.White;
            pnlFooter.Controls.Add(UITheme.MakeDivider(0, 0, 980));

            lblCount.Text = string.Empty; lblCount.Location = new Point(18, 14); lblCount.AutoSize = true;
            lblCount.Font = UITheme.FontSmall; lblCount.ForeColor = UITheme.TextSecondary; lblCount.Name = "lblCount";

            pnlFooter.Controls.Add(new Label
            {
                Text = "Grand Total:", Font = new Font("Segoe UI Semibold", 10F),
                ForeColor = UITheme.TextSecondary, Location = new Point(756, 14), AutoSize = true
            });

            lblGrandTotal.Text = string.Empty; lblGrandTotal.Location = new Point(854, 12); lblGrandTotal.AutoSize = true;
            lblGrandTotal.Font = new Font("Segoe UI Semibold", 13F); lblGrandTotal.ForeColor = UITheme.Success; lblGrandTotal.Name = "lblGrandTotal";

            pnlFooter.Controls.AddRange(new Control[] { lblCount, lblGrandTotal });

            this.Controls.AddRange(new Control[] { pnlHeader, pnlToolbar, pnlGridWrap, pnlFooter });
            this.ResumeLayout(false);
        }
    }
}

// [FILE PATH: BookstoreSystem3Tier/UI/ViewBooksForm.Designer.cs]
// FIXED: ClientSize + recalculated grid/footer so footer is never clipped.
//   header(72) + toolbar(52) + grid(502) + footer(34) = 660 px total

namespace UI
{
    partial class ViewBooksForm
    {
        private System.ComponentModel.IContainer components = null;
        private Panel        pnlHeader;
        private Label        lblFormTitle;
        private Panel        pnlToolbar;
        private Label        lblGenreFilter;
        private ComboBox     cmbGenreFilter;
        private Label        lblSearch;
        private TextBox      txtSearch;
        private Button       btnRefresh;
        private Panel        pnlGrid;
        private DataGridView dgvBooks;
        private Panel        pnlFooter;
        private Label        lblCount;
        private Label        lblStatus;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            pnlHeader      = new Panel();      lblFormTitle   = new Label();
            pnlToolbar     = new Panel();      lblGenreFilter = new Label();
            cmbGenreFilter = new ComboBox();   lblSearch      = new Label();
            txtSearch      = new TextBox();    btnRefresh     = new Button();
            pnlGrid        = new Panel();      dgvBooks       = new DataGridView();
            pnlFooter      = new Panel();      lblCount       = new Label();
            lblStatus      = new Label();

            this.SuspendLayout();

            this.Text            = "Book Catalogue";
            this.ClientSize      = new Size(920, 660);   // ← ClientSize
            this.StartPosition   = FormStartPosition.CenterParent;
            this.BackColor       = UITheme.Surface;
            this.Font            = UITheme.FontBase;

            // Header (0‒72)
            pnlHeader.Location  = new Point(0, 0);
            pnlHeader.Size      = new Size(920, 72);
            pnlHeader.BackColor = UITheme.PrimaryDark;
            pnlHeader.Controls.Add(UITheme.MakeTopStripe(920, UITheme.Primary, 4));

            lblFormTitle.Text = "Book Catalogue"; lblFormTitle.Font = new Font("Segoe UI Semibold", 17F);
            lblFormTitle.ForeColor = Color.White; lblFormTitle.Location = new Point(22, 10); lblFormTitle.AutoSize = true;

            pnlHeader.Controls.Add(new Label { Text = "Browse and search all available books — filter by genre or search by title / author", Font = new Font("Segoe UI", 8.5F, FontStyle.Italic), ForeColor = Color.FromArgb(140, 185, 230), Location = new Point(22, 46), AutoSize = true });
            pnlHeader.Controls.Add(lblFormTitle);

            // Toolbar (72‒124)
            pnlToolbar.Location  = new Point(0, 72);
            pnlToolbar.Size      = new Size(920, 52);
            pnlToolbar.BackColor = Color.White;
            pnlToolbar.Controls.Add(UITheme.MakeDivider(0, 51, 920));

            lblGenreFilter.Text = "Genre"; lblGenreFilter.Location = new Point(18, 17); lblGenreFilter.AutoSize = true;
            lblGenreFilter.Font = new Font("Segoe UI Semibold", 8.5F); lblGenreFilter.ForeColor = UITheme.Primary;

            cmbGenreFilter.Location = new Point(62, 13); cmbGenreFilter.Size = new Size(165, 30);
            cmbGenreFilter.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbGenreFilter.Items.AddRange(new object[] { "All Genres", "Action", "Fiction", "NonFiction", "Horror", "Manga" });
            cmbGenreFilter.SelectedIndex = 0; cmbGenreFilter.Name = "cmbGenreFilter";
            cmbGenreFilter.Font = UITheme.FontBase; cmbGenreFilter.FlatStyle = FlatStyle.Flat; cmbGenreFilter.BackColor = UITheme.Surface;
            cmbGenreFilter.SelectedIndexChanged += cmbGenreFilter_SelectedIndexChanged;

            pnlToolbar.Controls.Add(new Panel { Location = new Point(240, 12), Size = new Size(1, 28), BackColor = UITheme.Divider });

            lblSearch.Text = "Search"; lblSearch.Location = new Point(254, 17); lblSearch.AutoSize = true;
            lblSearch.Font = new Font("Segoe UI Semibold", 8.5F); lblSearch.ForeColor = UITheme.Primary;

            txtSearch.Location = new Point(306, 13); txtSearch.Size = new Size(378, 30);
            txtSearch.Font = UITheme.FontBase; txtSearch.BackColor = UITheme.Surface;
            txtSearch.BorderStyle = BorderStyle.FixedSingle; txtSearch.Name = "txtSearch";
            txtSearch.TextChanged += txtSearch_TextChanged;

            btnRefresh.Text = "Refresh"; btnRefresh.Location = new Point(778, 12); btnRefresh.Size = new Size(120, 30);
            btnRefresh.Click += btnRefresh_Click;
            UITheme.StyleButton(btnRefresh, UITheme.Primary, UITheme.PrimaryLight, font: UITheme.FontBtnSmall);

            pnlToolbar.Controls.AddRange(new Control[]
                { lblGenreFilter, cmbGenreFilter, lblSearch, txtSearch, btnRefresh });

            // Grid panel (124‒626)  — height=502 to leave exactly 34 px for footer
            pnlGrid.Location  = new Point(0, 124);
            pnlGrid.Size      = new Size(920, 502);
            pnlGrid.BackColor = Color.White;

            dgvBooks.Location = new Point(14, 12);
            dgvBooks.Size     = new Size(892, 478);
            dgvBooks.Name     = "dgvBooks";
            UITheme.StyleGrid(dgvBooks);
            dgvBooks.Columns.Add("colTitle",  "Book Title");
            dgvBooks.Columns.Add("colAuthor", "Author");
            dgvBooks.Columns.Add("colPrice",  "Price");
            dgvBooks.Columns.Add("colGenre",  "Genre");
            dgvBooks.Columns["colPrice"]!.DefaultCellStyle.Alignment = DataGridViewContentAlignment.MiddleRight;
            dgvBooks.Columns["colPrice"]!.Width = 88;
            dgvBooks.Columns["colGenre"]!.Width = 110;
            pnlGrid.Controls.Add(dgvBooks);

            // Footer (626‒660)
            pnlFooter.Location  = new Point(0, 626);
            pnlFooter.Size      = new Size(920, 34);
            pnlFooter.BackColor = UITheme.Surface;
            pnlFooter.Controls.Add(UITheme.MakeDivider(0, 0, 920));

            lblCount.Text = string.Empty; lblCount.Location = new Point(18, 10); lblCount.AutoSize = true;
            lblCount.Font = UITheme.FontSmall; lblCount.ForeColor = UITheme.TextSecondary; lblCount.Name = "lblCount";

            lblStatus.Text = string.Empty; lblStatus.Location = new Point(240, 10);
            lblStatus.Size = new Size(500, 18); lblStatus.AutoSize = false;
            lblStatus.Font = UITheme.FontSmall; lblStatus.Name = "lblStatus";

            pnlFooter.Controls.AddRange(new Control[] { lblCount, lblStatus });

            this.Controls.AddRange(new Control[] { pnlHeader, pnlToolbar, pnlGrid, pnlFooter });
            this.ResumeLayout(false);
        }
    }
}

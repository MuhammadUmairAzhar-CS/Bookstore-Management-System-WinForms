// [FILE PATH: BookstoreSystem3Tier/UI/BuyBookForm.Designer.cs]
// FIXED: ClientSize so confirm button and info card at bottom are never clipped.

namespace UI
{
    partial class BuyBookForm
    {
        private System.ComponentModel.IContainer components = null;
        private Panel   pnlHeader;
        private Panel   pnlBody;
        private Label   lblFormTitle;
        private Label   lblSubtitle;
        private Label   lblBookTitle;
        private TextBox txtBookTitle;
        private Label   lblQuantity;
        private TextBox txtQuantity;
        private Button  btnCalculate;
        private Panel   pnlBill;
        private Label   lblBookDetails;
        private Label   lblBillLabelL;
        private Label   lblBillAmount;
        private Button  btnPurchase;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            pnlHeader     = new Panel();  pnlBody      = new Panel();
            lblFormTitle  = new Label();  lblSubtitle  = new Label();
            lblBookTitle  = new Label();  txtBookTitle = new TextBox();
            lblQuantity   = new Label();  txtQuantity  = new TextBox();
            btnCalculate  = new Button(); pnlBill      = new Panel();
            lblBookDetails = new Label(); lblBillLabelL = new Label();
            lblBillAmount = new Label();  btnPurchase  = new Button();

            this.SuspendLayout();

            this.Text            = "Purchase a Book";
            this.ClientSize      = new Size(540, 560);   // ← ClientSize
            this.StartPosition   = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox     = false;
            this.BackColor       = UITheme.Surface;
            this.Font            = UITheme.FontBase;

            // Header (0‒70)
            pnlHeader.Location  = new Point(0, 0);
            pnlHeader.Size      = new Size(540, 70);
            pnlHeader.BackColor = UITheme.Primary;

            lblFormTitle.Text = "Purchase a Book"; lblFormTitle.Font = new Font("Segoe UI Semibold", 17F);
            lblFormTitle.ForeColor = Color.White; lblFormTitle.Location = new Point(22, 10); lblFormTitle.AutoSize = true;

            lblSubtitle.Text = "Enter a title and quantity, then review your order summary";
            lblSubtitle.Font = new Font("Segoe UI", 8.5F, FontStyle.Italic);
            lblSubtitle.ForeColor = Color.FromArgb(160, 200, 250); lblSubtitle.Location = new Point(22, 46); lblSubtitle.AutoSize = true;

            pnlHeader.Controls.AddRange(new Control[]
                { UITheme.MakeTopStripe(540, UITheme.Primary, 4), lblFormTitle, lblSubtitle });

            // Body (70‒560) — 490 px of work area
            //   Positions inside pnlBody:
            //   Step 1 bar:      y=0    h=34
            //   Title label:     y=46
            //   Title input:     y=66   h=36  bottom=102
            //   Qty label:       y=114
            //   Qty input:       y=134  h=36  bottom=170
            //   Calc button:     y=186  h=46  bottom=232
            //   Step 2 bar:      y=248  h=34
            //   Bill card:       y=290  h=90  (hidden until calculated)
            //   Confirm button:  y=394  h=50  bottom=444
            //   Info card:       y=454  h=28  bottom=482  (fits in 490)

            pnlBody.Location  = new Point(0, 70);
            pnlBody.Size      = new Size(540, 490);
            pnlBody.BackColor = Color.White;

            const int bx = 28, bw = 484;

            var step1 = new Panel { Location = new Point(0, 0), Size = new Size(540, 34), BackColor = UITheme.Surface };
            step1.Controls.Add(new Label { Text = "STEP 1 — SELECT A BOOK AND QUANTITY", Font = UITheme.FontLabel, ForeColor = UITheme.Primary, Location = new Point(bx, 10), AutoSize = true });

            FL(lblBookTitle, "BOOK TITLE (exact match required)", bx, 46); TX(txtBookTitle, "txtBookTitle", bx, 66, bw);
            FL(lblQuantity,  "QUANTITY (number of copies)",       bx, 114); TX(txtQuantity, "txtQuantity",  bx, 134, bw);
            txtQuantity.KeyPress += txtQuantity_KeyPress;

            btnCalculate.Text = "Calculate Total Price"; btnCalculate.Location = new Point(bx, 186); btnCalculate.Size = new Size(bw, 46);
            btnCalculate.Click += btnCalculate_Click;
            UITheme.StyleButton(btnCalculate, UITheme.Primary, UITheme.PrimaryLight, font: new Font("Segoe UI Semibold", 10.5F));

            var step2 = new Panel { Location = new Point(0, 248), Size = new Size(540, 34), BackColor = UITheme.Surface };
            step2.Controls.Add(new Label { Text = "STEP 2 — REVIEW ORDER SUMMARY AND CONFIRM", Font = UITheme.FontLabel, ForeColor = UITheme.Success, Location = new Point(bx, 10), AutoSize = true });

            // Bill summary card (hidden until calculated)
            pnlBill.Location = new Point(bx, 290); pnlBill.Size = new Size(bw, 90);
            pnlBill.BackColor = UITheme.SuccessLight; pnlBill.Visible = false;

            var billBar = new Panel { Location = new Point(0, 0), Size = new Size(5, 90), BackColor = UITheme.Success };
            var billHead = new Label { Text = "ORDER SUMMARY", Font = UITheme.FontLabel, ForeColor = UITheme.Success, Location = new Point(18, 8), AutoSize = true };

            lblBookDetails.Text = string.Empty; lblBookDetails.Location = new Point(18, 28);
            lblBookDetails.Size = new Size(bw - 40, 20); lblBookDetails.AutoSize = false;
            lblBookDetails.Font = UITheme.FontBase; lblBookDetails.ForeColor = UITheme.TextSecondary; lblBookDetails.Name = "lblBookDetails";

            lblBillLabelL.Text = "Total due:"; lblBillLabelL.Location = new Point(18, 60);
            lblBillLabelL.AutoSize = true; lblBillLabelL.Font = new Font("Segoe UI", 10F); lblBillLabelL.ForeColor = UITheme.TextSecondary;

            lblBillAmount.Text = "$0.00"; lblBillAmount.Location = new Point(100, 54);
            lblBillAmount.AutoSize = true; lblBillAmount.Font = new Font("Segoe UI Semibold", 20F);
            lblBillAmount.ForeColor = UITheme.Success; lblBillAmount.Name = "lblBillAmount";

            pnlBill.Controls.AddRange(new Control[] { billBar, billHead, lblBookDetails, lblBillLabelL, lblBillAmount });

            btnPurchase.Text = "Confirm and Complete Purchase"; btnPurchase.Location = new Point(bx, 394); btnPurchase.Size = new Size(bw, 48);
            btnPurchase.Enabled = false; btnPurchase.Click += btnPurchase_Click;
            UITheme.StyleButton(btnPurchase, UITheme.Success, Color.FromArgb(21, 128, 61), font: new Font("Segoe UI Semibold", 11F));

            var infoCard = UITheme.MakeInfoCard(bx, 454, bw, 28,
                "WHAT HAPPENS NEXT?",
                "Your purchase is instantly recorded in Transaction History.",
                UITheme.Primary, UITheme.PrimaryPale);

            pnlBody.Controls.AddRange(new Control[]
            {
                step1, lblBookTitle, txtBookTitle, lblQuantity, txtQuantity,
                btnCalculate, step2, pnlBill, btnPurchase, infoCard
            });

            this.Controls.AddRange(new Control[] { pnlHeader, pnlBody });
            this.ResumeLayout(false);
        }

        private static void FL(Label l, string t, int x, int y)
        { l.Text = t; l.Font = UITheme.FontLabel; l.ForeColor = UITheme.TextSecondary; l.Location = new Point(x, y); l.AutoSize = true; }

        private static void TX(TextBox t, string n, int x, int y, int w)
        { t.Name = n; t.Location = new Point(x, y); t.Size = new Size(w, 36); t.Font = UITheme.FontBase; t.BorderStyle = BorderStyle.FixedSingle; t.BackColor = UITheme.Surface; t.ForeColor = UITheme.TextPrimary; }
    }
}

// [FILE PATH: BookstoreSystem3Tier/UI/BuyBookForm.cs]
using BL.Services;
using DL;

namespace UI
{
    public partial class BuyBookForm : Form
    {
        private readonly UserRecord _currentUser;
        private decimal             _totalPrice;
        private string              _confirmedTitle = string.Empty;
        private int                 _confirmedQty;

        public BuyBookForm(UserRecord user)
        {
            _currentUser = user;
            InitializeComponent();
        }

        private void btnCalculate_Click(object sender, EventArgs e)
        {
            string title   = txtBookTitle.Text.Trim();
            string qtyText = txtQuantity.Text.Trim();

            var (result, total) = BookService.ProcessPurchase(title, qtyText);

            if (!result.Success)
            {
                ShowWarning(result.Message);
                ResetBill();
                return;
            }

            _totalPrice     = total;
            _confirmedTitle = title;
            int.TryParse(qtyText, out _confirmedQty);

            lblBillAmount.Text  = $"${total:F2}";
            lblBookDetails.Text = $"{title}   \u00d7   {qtyText} copies";
            pnlBill.Visible     = true;
            btnPurchase.Enabled = true;
        }

        private void btnPurchase_Click(object sender, EventArgs e)
        {
            var confirm = MessageBox.Show(
                $"Confirm your purchase:\n\n" +
                $"Book:    {_confirmedTitle}\n" +
                $"Qty:     {_confirmedQty}\n" +
                $"Total:   ${_totalPrice:F2}\n\n" +
                $"Proceed?",
                "Confirm Purchase",
                MessageBoxButtons.YesNo, MessageBoxIcon.Question);

            if (confirm != DialogResult.Yes) return;

            var book    = BookService.FindBook(_confirmedTitle);
            decimal unit = book?.Price ?? (_confirmedQty > 0 ? _totalPrice / _confirmedQty : 0);

            BookService.AppendPurchaseLog(
                _currentUser.Username, _confirmedTitle,
                _confirmedQty, unit, _totalPrice);

            ShowInfo(
                $"Purchase completed successfully!\n\n" +
                $"Customer:  {_currentUser.Username}\n" +
                $"Book:      {_confirmedTitle}\n" +
                $"Quantity:  {_confirmedQty}\n" +
                $"Total:     ${_totalPrice:F2}\n\n" +
                $"Thank you for your purchase!");

            ResetForm();
        }

        private void txtQuantity_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (!char.IsDigit(e.KeyChar) && e.KeyChar != '\b')
                e.Handled = true;
        }

        private void ResetBill()
        {
            lblBillAmount.Text  = "$0.00";
            lblBookDetails.Text = string.Empty;
            pnlBill.Visible     = false;
            btnPurchase.Enabled = false;
            _totalPrice         = 0;
            _confirmedTitle     = string.Empty;
            _confirmedQty       = 0;
        }

        private void ResetForm()
        {
            txtBookTitle.Clear();
            txtQuantity.Clear();
            ResetBill();
        }

        private static void ShowWarning(string m) =>
            MessageBox.Show(m, "Validation Error",    MessageBoxButtons.OK, MessageBoxIcon.Warning);

        private static void ShowInfo(string m) =>
            MessageBox.Show(m, "Purchase Successful", MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
}

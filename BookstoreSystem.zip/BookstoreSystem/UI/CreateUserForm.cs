// [FILE PATH: BookstoreSystem3Tier/UI/CreateUserForm.cs]
// ─────────────────────────────────────────────────────────────────────────────
// UI LAYER — Create User Form (Admin action)
// An admin fills in username, password, email, and role; clicks Create Account.
// Calls AdminUserService which validates and persists the new record.
// ─────────────────────────────────────────────────────────────────────────────

using BL.Services;

namespace UI
{
    public partial class CreateUserForm : Form
    {
        /// <summary>Set to true after a successful account creation.</summary>
        public bool AccountCreated { get; private set; }

        public CreateUserForm()
        {
            InitializeComponent();
        }

        // ── Password Show/Hide toggles ────────────────────────────────────────
        private void btnTogglePwd_Click(object sender, EventArgs e)
        {
            txtPassword.UseSystemPasswordChar = !txtPassword.UseSystemPasswordChar;
            btnTogglePwd.Text = txtPassword.UseSystemPasswordChar ? "Show" : "Hide";
        }

        private void btnToggleConfirm_Click(object sender, EventArgs e)
        {
            txtConfirmPassword.UseSystemPasswordChar = !txtConfirmPassword.UseSystemPasswordChar;
            btnToggleConfirm.Text = txtConfirmPassword.UseSystemPasswordChar ? "Show" : "Hide";
        }

        // ── Create Account ────────────────────────────────────────────────────
        private void btnCreate_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text.Trim();
            string password = txtPassword.Text;
            string confirm  = txtConfirmPassword.Text;
            string email    = txtEmail.Text.Trim();
            string role     = cmbRole.SelectedItem?.ToString() ?? "User";

            var result = AdminUserService.CreateUser(username, password, confirm, email, role);

            if (!result.Success)
            {
                ShowStatus(result.Message, success: false);
                return;
            }

            ShowStatus($"Account \"{username}\" ({role}) created successfully!", success: true);
            AccountCreated = true;

            // Clear the form so admin can create another account
            txtUsername.Clear();
            txtPassword.Clear();
            txtConfirmPassword.Clear();
            txtEmail.Clear();
            cmbRole.SelectedIndex = 0;
            txtUsername.Focus();
        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        // ── Clear all fields ──────────────────────────────────────────────────
        private void btnClearAll_Click(object sender, EventArgs e)
        {
            txtUsername.Clear();
            txtPassword.Clear();
            txtConfirmPassword.Clear();
            txtEmail.Clear();
            cmbRole.SelectedIndex = 0;
            lblStatus.Text = string.Empty;
            txtUsername.Focus();
        }

        private void ShowStatus(string message, bool success)
        {
            lblStatus.Text      = message;
            lblStatus.ForeColor = success ? UITheme.Success : UITheme.Danger;
        }
    }
}

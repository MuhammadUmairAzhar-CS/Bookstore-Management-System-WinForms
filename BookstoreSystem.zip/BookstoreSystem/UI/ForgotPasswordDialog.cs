// [FILE PATH: BookstoreSystem3Tier/UI/ForgotPasswordDialog.cs]
using BL.Services;

namespace UI
{
    public partial class ForgotPasswordDialog : Form
    {
        private readonly string _role;

        public ForgotPasswordDialog(string role)
        {
            _role = role;
            InitializeComponent();
            lblRoleInfo.Text = $"Searching {role} accounts";
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string email = txtEmail.Text.Trim();
            var (username, error) = AuthService.RecoverByEmail(email, _role);

            if (username is null)
            {
                MessageBox.Show(error, "Account Not Found",
                    MessageBoxButtons.OK, MessageBoxIcon.Warning);
                return;
            }

            MessageBox.Show(
                $"Account found!\n\nYour {_role} username is:  {username}\n\n" +
                "Contact support if you also need to reset your password.",
                "Account Found",
                MessageBoxButtons.OK, MessageBoxIcon.Information);

            this.Close();
        }

        private void btnCancel_Click(object sender, EventArgs e) => this.Close();
    }
}

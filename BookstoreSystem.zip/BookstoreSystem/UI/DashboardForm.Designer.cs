namespace UI
{
    partial class DashboardForm
    {
        private System.ComponentModel.IContainer components = null;

        private Panel pnlHeader;
        private Label lblWelcomeName;
        private Label lblRoleBadge;
        private Label lblAppName;
        private Panel pnlUserLayout;
        private Panel pnlAdminLayout;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.SuspendLayout();

            pnlHeader = new Panel();
            lblWelcomeName = new Label();
            lblRoleBadge = new Label();
            lblAppName = new Label();
            pnlUserLayout = new Panel();
            pnlAdminLayout = new Panel();

            // ── Form ────────────────────────────────────────────────────────
            this.Text = "Bookstore Management System";
            this.ClientSize = new Size(760, 660);
            this.StartPosition = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox = false;
            this.BackColor = Color.White;
            this.Font = UITheme.FontBase;

            // ── Header ───────────────────────────────────────────────────────
            pnlHeader.Location = new Point(0, 0);
            pnlHeader.Size = new Size(760, 84);
            pnlHeader.BackColor = UITheme.PrimaryDark;
            pnlHeader.Controls.Add(UITheme.MakeTopStripe(760, UITheme.Accent, 4));

            lblAppName.Text = "BOOKSTORE MANAGEMENT SYSTEM";
            lblAppName.Font = new Font("Segoe UI", 7.5F, FontStyle.Bold);
            lblAppName.ForeColor = Color.FromArgb(100, 145, 210);
            lblAppName.Location = new Point(24, 16);
            lblAppName.AutoSize = true;

            lblWelcomeName.Text = "Dashboard";
            lblWelcomeName.Font = new Font("Segoe UI Semibold", 19F);
            lblWelcomeName.ForeColor = Color.White;
            lblWelcomeName.Location = new Point(24, 34);
            lblWelcomeName.AutoSize = true;
            lblWelcomeName.Name = "lblWelcomeName";

            lblRoleBadge.Text = "USER";
            lblRoleBadge.Font = new Font("Segoe UI Semibold", 8F);
            lblRoleBadge.ForeColor = Color.White;
            lblRoleBadge.BackColor = UITheme.Primary;
            lblRoleBadge.Location = new Point(672, 34);
            lblRoleBadge.Size = new Size(62, 22);
            lblRoleBadge.TextAlign = ContentAlignment.MiddleCenter;
            lblRoleBadge.Name = "lblRoleBadge";

            pnlHeader.Controls.AddRange(new Control[] { lblAppName, lblWelcomeName, lblRoleBadge });

            BuildUserLayout();
            BuildAdminLayout();

            pnlUserLayout.Location = new Point(0, 84);
            pnlAdminLayout.Location = new Point(0, 84);

            this.Controls.AddRange(new Control[] { pnlHeader, pnlUserLayout, pnlAdminLayout });
            this.ResumeLayout(false);
        }

        private void BuildUserLayout()
        {
            pnlUserLayout.Size = new Size(760, 576);
            pnlUserLayout.BackColor = Color.White;
            pnlUserLayout.Visible = false;

            var sec1 = new Panel { Location = new Point(0, 0), Size = new Size(760, 38), BackColor = UITheme.Surface };
            sec1.Controls.Add(new Label { Text = "YOUR ACCOUNT MENU", Font = UITheme.FontLabel, ForeColor = UITheme.Primary, Location = new Point(28, 12), AutoSize = true });

            var rowView = MakeMenuRow(38, 760, UITheme.Primary, "Browse Book Catalogue", "Search and filter all available books by genre, author, or title.", btnViewBooks_Click);
            var rowBuy = MakeMenuRow(126, 760, UITheme.Success, "Purchase a Book", "Select a title, enter the quantity, review your total, and confirm the purchase in two steps.", btnBuyBook_Click);
            var rowHistory = MakeMenuRow(214, 760, UITheme.Info, "View My Transaction History", "See a complete log of every book you have purchased.", btnHistory_Click);

            var sec2 = new Panel { Location = new Point(0, 316), Size = new Size(760, 38), BackColor = UITheme.Surface };
            sec2.Controls.Add(new Label { Text = "SESSION", Font = UITheme.FontLabel, ForeColor = UITheme.TextMuted, Location = new Point(28, 12), AutoSize = true });

            var rowOut = MakeMenuRow(354, 760, UITheme.Danger, "Sign Out of My Account", "Securely end your current session.", btnLogout_Click);

            AppendSystemOverview(pnlUserLayout, 458);
            pnlUserLayout.Controls.AddRange(new Control[] { sec1, rowView, rowBuy, rowHistory, sec2, rowOut });
        }

        private void BuildAdminLayout()
        {
            pnlAdminLayout.Size = new Size(760, 576);
            pnlAdminLayout.BackColor = Color.White;
            pnlAdminLayout.Visible = false;

            const int lw = 380, rx = 380, rw = 380;
            var colSep = new Panel { Location = new Point(lw, 0), Size = new Size(1, 500), BackColor = UITheme.Divider };

            var lhdr = new Panel { Location = new Point(0, 0), Size = new Size(lw, 38), BackColor = UITheme.Primary };
            lhdr.Controls.Add(new Label { Text = "GENERAL", Font = new Font("Segoe UI Semibold", 8F), ForeColor = Color.White, Location = new Point(24, 12), AutoSize = true });

            var aView = MakeCompactRow(38, lw, UITheme.Primary, "Browse Book Catalogue", "View, search, and filter all available books.", btnViewBooks_Click);
            var aHistory = MakeCompactRow(112, lw, UITheme.Info, "View Transaction History", "Full audit log of every confirmed purchase.", btnHistory_Click);

            pnlAdminLayout.Controls.Add(UITheme.MakeDivider(24, 186, lw - 48));
            pnlAdminLayout.Controls.Add(UITheme.MakeSectionLabel("SESSION", 24, 196));
            var aOut = MakeCompactRow(214, lw, UITheme.Danger, "Sign Out", "End your admin session.", btnLogout_Click);

            var rhdr = new Panel { Location = new Point(rx, 0), Size = new Size(rw, 38), BackColor = UITheme.AdminColor };
            rhdr.Controls.Add(new Label { Text = "ADMINISTRATION", Font = new Font("Segoe UI Semibold", 8F), ForeColor = Color.White, Location = new Point(24, 12), AutoSize = true });

            var aAdd = MakeCompactRowRight(rx, 38, rw, UITheme.Success, "Add New Book", "Add a new title to the catalogue.", btnAddBook_Click);
            var aDel = MakeCompactRowRight(rx, 112, rw, UITheme.Danger, "Remove a Book", "Confirm permanent deletion.", btnDeleteBook_Click);

            pnlAdminLayout.Controls.Add(new Panel { Location = new Point(rx + 24, 186), Size = new Size(rw - 48, 1), BackColor = UITheme.Divider });
            var uMgmtLabel = UITheme.MakeSectionLabel("USER MANAGEMENT", rx + 24, 196);
            uMgmtLabel.ForeColor = UITheme.AdminColor;
            pnlAdminLayout.Controls.Add(uMgmtLabel);

            var aManageUsers = MakeCompactRowRight(rx, 214, rw, UITheme.AdminColor, "Manage User Accounts", "Inspect accounts and purchase history.", btnManageUsers_Click);
            var aCreateUser = MakeCompactRowRight(rx, 288, rw, UITheme.Primary, "Create New User Account", "Set up a new user or admin.", btnCreateUser_Click);

            AppendSystemOverview(pnlAdminLayout, 382);
            pnlAdminLayout.Controls.AddRange(new Control[] { colSep, lhdr, aView, aHistory, aOut, rhdr, aAdd, aDel, aManageUsers, aCreateUser });
        }

        // ── Corrected Row Factory Helpers ───────────────────────────────────────────────

        private Panel MakeMenuRow(int y, int width, Color iconColor, string title, string desc, EventHandler click)
        {
            var row = new Panel { Location = new Point(0, y), Size = new Size(width, 88), BackColor = Color.White, Cursor = Cursors.Hand };
            var icon = new Panel { Location = new Point(28, 28), Size = new Size(10, 10), BackColor = iconColor };
            var lblTitle = new Label { Text = title, Font = new Font("Segoe UI Semibold", 11.5F), ForeColor = UITheme.TextPrimary, Location = new Point(50, 16), AutoSize = true };
            var lblDesc = new Label { Text = desc, Font = new Font("Segoe UI", 8.5F), ForeColor = UITheme.TextSecondary, Location = new Point(50, 44), Size = new Size(width - 110, 32), AutoSize = false };
            var lblArrow = new Label { Text = "\u203a", Font = new Font("Segoe UI", 18F), ForeColor = UITheme.TextMuted, Location = new Point(width - 38, 26), AutoSize = true };

            row.Click += click; icon.Click += click; lblTitle.Click += click; lblDesc.Click += click; lblArrow.Click += click;
            row.Controls.AddRange(new Control[] { icon, lblTitle, lblDesc, lblArrow, UITheme.MakeDivider(0, 87, width) });
            return row;
        }

        private Panel MakeCompactRow(int y, int cw, Color iconColor, string title, string desc, EventHandler click)
        {
            var row = new Panel { Location = new Point(0, y), Size = new Size(cw, 74), BackColor = Color.White, Cursor = Cursors.Hand };
            var icon = new Panel { Location = new Point(24, 22), Size = new Size(8, 8), BackColor = iconColor };
            var lblTitle = new Label { Text = title, Font = new Font("Segoe UI Semibold", 10F), ForeColor = UITheme.TextPrimary, Location = new Point(42, 12), AutoSize = true };
            var lblDesc = new Label { Text = desc, Font = new Font("Segoe UI", 8F), ForeColor = UITheme.TextSecondary, Location = new Point(42, 36), Size = new Size(cw - 70, 28), AutoSize = false };
            var lblArrow = new Label { Text = "\u203a", Font = new Font("Segoe UI", 16F), ForeColor = UITheme.TextMuted, Location = new Point(cw - 28, 18), AutoSize = true };

            row.Click += click; icon.Click += click; lblTitle.Click += click; lblDesc.Click += click; lblArrow.Click += click;
            row.Controls.AddRange(new Control[] { icon, lblTitle, lblDesc, lblArrow, UITheme.MakeDivider(0, 73, cw) });
            return row;
        }

        private Panel MakeCompactRowRight(int x, int y, int cw, Color iconColor, string title, string desc, EventHandler click)
        {
            var row = new Panel { Location = new Point(x, y), Size = new Size(cw, 74), BackColor = Color.White, Cursor = Cursors.Hand };
            var icon = new Panel { Location = new Point(24, 22), Size = new Size(8, 8), BackColor = iconColor };
            var lblTitle = new Label { Text = title, Font = new Font("Segoe UI Semibold", 10F), ForeColor = UITheme.TextPrimary, Location = new Point(42, 12), AutoSize = true };
            var lblDesc = new Label { Text = desc, Font = new Font("Segoe UI", 8F), ForeColor = UITheme.TextSecondary, Location = new Point(42, 36), Size = new Size(cw - 70, 28), AutoSize = false };
            var lblArrow = new Label { Text = "\u203a", Font = new Font("Segoe UI", 16F), ForeColor = UITheme.TextMuted, Location = new Point(cw - 28, 18), AutoSize = true };

            row.Click += click; icon.Click += click; lblTitle.Click += click; lblDesc.Click += click; lblArrow.Click += click;
            row.Controls.AddRange(new Control[] { icon, lblTitle, lblDesc, lblArrow, UITheme.MakeDivider(0, 73, cw) });
            return row;
        }

        private static void AppendSystemOverview(Panel parent, int y)
        {
            var bg = new Panel { Location = new Point(0, y), Size = new Size(760, 52), BackColor = UITheme.Surface };
            bg.Controls.Add(UITheme.MakeDivider(0, 0, 760));
            var lh = UITheme.MakeSectionLabel("DATA STORES", 28, 10);
            lh.ForeColor = UITheme.Primary;
            bg.Controls.Add(lh);
            int tx = 28;
            foreach (var name in new[] { "User Accounts", "Admin Accounts", "Book Catalogue", "Purchase Records", "Error Logs" })
            {
                bg.Controls.Add(new Panel { Location = new Point(tx, 34), Size = new Size(6, 6), BackColor = UITheme.Success });
                bg.Controls.Add(new Label { Text = name, Font = new Font("Segoe UI", 8F), ForeColor = UITheme.TextSecondary, Location = new Point(tx + 10, 28), AutoSize = true });
                tx += 138;
            }
            parent.Controls.Add(bg);
        }
    }
}
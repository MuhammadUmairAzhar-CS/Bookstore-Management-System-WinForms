// [FILE PATH: BookstoreSystem3Tier/UI/ManageUsersForm.Designer.cs]
// ─────────────────────────────────────────────────────────────────────────────
// IMPROVED: Admin User Management form
//   Left  (580 px): DataGridView with all accounts + toolbar
//   Right (380 px): Detail panel for selected account
//   ClientSize used for exact layout
//   Layout: header(72) + toolbar(56) + content(532) = 660 px
// ─────────────────────────────────────────────────────────────────────────────

namespace UI
{
    partial class ManageUsersForm
    {
        private System.ComponentModel.IContainer components = null;

        private Panel        pnlHeader;
        private Label        lblFormTitle;
        private Panel        pnlToolbar;
        private Button       btnCreateUser;
        private Button       btnRefresh;
        private TextBox      txtSearch;
        private ComboBox     cmbRoleFilter;
        private Panel        pnlGrid;
        private DataGridView dgvUsers;
        private Panel        pnlFooter;
        private Label        lblCount;
        private Label        lblStatus;
        private Button       btnDeleteUser;

        // Detail panel controls
        private Panel  pnlDetail;
        private Label  lblDetailHead;
        private Label  lblDetailUsername;
        private Label  lblDetailRoleBadge;
        private Label  lblDetailEmail;
        private Label  lblDetailRole;
        private Label  lblDetailPurchases;
        private Label  lblDetailHistHead;
        private ListBox lstDetailHistory;

        protected override void Dispose(bool disposing)
        {
            if (disposing && components != null) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components    = new System.ComponentModel.Container();
            pnlHeader         = new Panel();      lblFormTitle      = new Label();
            pnlToolbar        = new Panel();      btnCreateUser     = new Button();
            btnRefresh        = new Button();     txtSearch         = new TextBox();
            cmbRoleFilter     = new ComboBox();   pnlGrid           = new Panel();
            dgvUsers          = new DataGridView(); pnlFooter       = new Panel();
            lblCount          = new Label();      lblStatus         = new Label();
            btnDeleteUser     = new Button();     pnlDetail         = new Panel();
            lblDetailHead     = new Label();      lblDetailUsername  = new Label();
            lblDetailRoleBadge = new Label();     lblDetailEmail    = new Label();
            lblDetailRole     = new Label();      lblDetailPurchases = new Label();
            lblDetailHistHead = new Label();      lstDetailHistory  = new ListBox();

            this.SuspendLayout();

            // ── Form ───────────────────────────────────────────────────────────
            this.Text            = "Manage User Accounts — Admin";
            this.ClientSize      = new Size(960, 660);
            this.StartPosition   = FormStartPosition.CenterParent;
            this.BackColor       = UITheme.Surface;
            this.Font            = UITheme.FontBase;

            // ── Header (0‒72) ─────────────────────────────────────────────────
            pnlHeader.Location  = new Point(0, 0);
            pnlHeader.Size      = new Size(960, 72);
            pnlHeader.BackColor = UITheme.AdminColor;
            pnlHeader.Controls.Add(UITheme.MakeTopStripe(960, UITheme.Accent, 4));

            var badge = UITheme.MakeBadge("ADMIN ONLY",
                Color.FromArgb(40, 0, 0, 0), Color.FromArgb(255, 240, 190));
            badge.Location = new Point(868, 16);

            lblFormTitle.Text      = "Manage User Accounts";
            lblFormTitle.Font      = new Font("Segoe UI Semibold", 17F);
            lblFormTitle.ForeColor = Color.White;
            lblFormTitle.Location  = new Point(22, 10);
            lblFormTitle.AutoSize  = true;

            pnlHeader.Controls.Add(new Label
            {
                Text = "View, search, and manage all registered accounts — create or delete users",
                Font = new Font("Segoe UI", 8.5F, FontStyle.Italic),
                ForeColor = Color.FromArgb(190, 220, 255),
                Location  = new Point(22, 46),
                AutoSize  = true
            });
            pnlHeader.Controls.AddRange(new Control[] { badge, lblFormTitle });

            // ── Toolbar (72‒128) ───────────────────────────────────────────────
            pnlToolbar.Location  = new Point(0, 72);
            pnlToolbar.Size      = new Size(960, 56);
            pnlToolbar.BackColor = Color.White;
            pnlToolbar.Controls.Add(UITheme.MakeDivider(0, 55, 960));

            // Create New User button
            btnCreateUser.Text     = "+ Create New User";
            btnCreateUser.Location = new Point(18, 12);
            btnCreateUser.Size     = new Size(164, 32);
            btnCreateUser.Click   += btnCreateUser_Click;
            UITheme.StyleButton(btnCreateUser, UITheme.AdminColor,
                Color.FromArgb(109, 40, 217),
                font: new Font("Segoe UI Semibold", 9F));

            // Role filter
            pnlToolbar.Controls.Add(new Label
            {
                Text = "Role", Font = new Font("Segoe UI Semibold", 8.5F),
                ForeColor = UITheme.Primary, Location = new Point(196, 19), AutoSize = true
            });
            cmbRoleFilter.Location      = new Point(228, 14);
            cmbRoleFilter.Size          = new Size(130, 30);
            cmbRoleFilter.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbRoleFilter.Items.AddRange(new object[] { "All Roles", "User", "Admin" });
            cmbRoleFilter.SelectedIndex          = 0;
            cmbRoleFilter.Font                   = UITheme.FontBase;
            cmbRoleFilter.FlatStyle              = FlatStyle.Flat;
            cmbRoleFilter.BackColor              = UITheme.Surface;
            cmbRoleFilter.Name                   = "cmbRoleFilter";
            cmbRoleFilter.SelectedIndexChanged  += cmbRoleFilter_SelectedIndexChanged;

            // Separator
            pnlToolbar.Controls.Add(new Panel
            {
                Location  = new Point(372, 14),
                Size      = new Size(1, 28),
                BackColor = UITheme.Divider
            });

            // Search
            pnlToolbar.Controls.Add(new Label
            {
                Text = "Search", Font = new Font("Segoe UI Semibold", 8.5F),
                ForeColor = UITheme.Primary, Location = new Point(382, 19), AutoSize = true
            });
            txtSearch.Location     = new Point(432, 14);
            txtSearch.Size         = new Size(280, 30);
            txtSearch.Font         = UITheme.FontBase;
            txtSearch.BackColor    = UITheme.Surface;
            txtSearch.BorderStyle  = BorderStyle.FixedSingle;
            txtSearch.Name         = "txtSearch";
            txtSearch.TextChanged += txtSearch_TextChanged;

            // Refresh
            btnRefresh.Text     = "Refresh";
            btnRefresh.Location = new Point(826, 13);
            btnRefresh.Size     = new Size(112, 32);
            btnRefresh.Click   += btnRefresh_Click;
            UITheme.StyleButton(btnRefresh, UITheme.Primary, UITheme.PrimaryLight,
                font: UITheme.FontBtnSmall);

            pnlToolbar.Controls.AddRange(new Control[]
                { btnCreateUser, cmbRoleFilter, txtSearch, btnRefresh });

            // ── Content area (128‒626) ─────────────────────────────────────────
            // Vertical splitter at x=580: grid (0‒580) | detail (580‒960)

            var splitter = new Panel
            {
                Location  = new Point(580, 128),
                Size      = new Size(1, 498),
                BackColor = UITheme.Divider
            };

            // ── Left: DataGridView (128‒626) ───────────────────────────────────
            pnlGrid.Location  = new Point(0, 128);
            pnlGrid.Size      = new Size(580, 498);
            pnlGrid.BackColor = Color.White;

            dgvUsers.Location = new Point(0, 0);
            dgvUsers.Size     = new Size(580, 498);
            dgvUsers.Name     = "dgvUsers";
            UITheme.StyleGrid(dgvUsers);

            dgvUsers.Columns.Add("colUsername",  "Username");
            dgvUsers.Columns.Add("colEmail",     "Email");
            dgvUsers.Columns.Add("colRole",      "Role");
            dgvUsers.Columns.Add("colPurchases", "Purchases");
            dgvUsers.Columns.Add("colSpent",     "Total Spent");

            dgvUsers.Columns["colUsername"]!.Width  = 120;
            dgvUsers.Columns["colEmail"]!.Width     = 180;
            dgvUsers.Columns["colRole"]!.Width      = 70;
            dgvUsers.Columns["colPurchases"]!.Width = 84;
            dgvUsers.Columns["colSpent"]!.Width     = 100;
            dgvUsers.Columns["colPurchases"]!.DefaultCellStyle.Alignment =
                DataGridViewContentAlignment.MiddleCenter;
            dgvUsers.Columns["colSpent"]!.DefaultCellStyle.Alignment =
                DataGridViewContentAlignment.MiddleRight;

            dgvUsers.SelectionChanged += dgvUsers_SelectionChanged;

            pnlGrid.Controls.Add(dgvUsers);

            // ── Right: Detail panel (128‒626, x=581) ─────────────────────────
            pnlDetail.Location  = new Point(581, 128);
            pnlDetail.Size      = new Size(379, 498);
            pnlDetail.BackColor = Color.White;
            pnlDetail.Visible   = false;

            // Purple accent strip at top of detail panel
            var detailAccent = new Panel
            {
                Location  = new Point(0, 0),
                Size      = new Size(379, 4),
                BackColor = UITheme.AdminColor
            };

            // Section heading
            lblDetailHead.Text      = "ACCOUNT DETAILS";
            lblDetailHead.Font      = UITheme.FontLabel;
            lblDetailHead.ForeColor = UITheme.AdminColor;
            lblDetailHead.Location  = new Point(22, 18);
            lblDetailHead.AutoSize  = true;

            // Username + role badge on same row
            lblDetailUsername.Text      = string.Empty;
            lblDetailUsername.Font      = new Font("Segoe UI Semibold", 14F);
            lblDetailUsername.ForeColor = UITheme.TextPrimary;
            lblDetailUsername.Location  = new Point(22, 38);
            lblDetailUsername.AutoSize  = true;
            lblDetailUsername.Name      = "lblDetailUsername";

            lblDetailRoleBadge.Text      = string.Empty;
            lblDetailRoleBadge.Font      = new Font("Segoe UI Semibold", 8F);
            lblDetailRoleBadge.ForeColor = Color.White;
            lblDetailRoleBadge.BackColor = UITheme.Primary;
            lblDetailRoleBadge.Location  = new Point(22, 68);
            lblDetailRoleBadge.Size      = new Size(58, 20);
            lblDetailRoleBadge.TextAlign = ContentAlignment.MiddleCenter;
            lblDetailRoleBadge.Name      = "lblDetailRoleBadge";

            pnlDetail.Controls.Add(UITheme.MakeDivider(22, 100, 330));

            // Email row
            pnlDetail.Controls.Add(UITheme.MakeSectionLabel("EMAIL ADDRESS", 22, 112));
            lblDetailEmail.Text      = string.Empty;
            lblDetailEmail.Font      = UITheme.FontBase;
            lblDetailEmail.ForeColor = UITheme.TextPrimary;
            lblDetailEmail.Location  = new Point(22, 128);
            lblDetailEmail.AutoSize  = true;
            lblDetailEmail.Name      = "lblDetailEmail";

            // Role row
            pnlDetail.Controls.Add(UITheme.MakeSectionLabel("ROLE", 22, 156));
            lblDetailRole.Text      = string.Empty;
            lblDetailRole.Font      = UITheme.FontBase;
            lblDetailRole.ForeColor = UITheme.TextPrimary;
            lblDetailRole.Location  = new Point(22, 172);
            lblDetailRole.AutoSize  = true;
            lblDetailRole.Name      = "lblDetailRole";

            pnlDetail.Controls.Add(UITheme.MakeDivider(22, 200, 330));

            // Purchase summary
            pnlDetail.Controls.Add(UITheme.MakeSectionLabel("PURCHASE SUMMARY", 22, 212));
            lblDetailPurchases.Text      = string.Empty;
            lblDetailPurchases.Font      = UITheme.FontBase;
            lblDetailPurchases.ForeColor = UITheme.Success;
            lblDetailPurchases.Location  = new Point(22, 228);
            lblDetailPurchases.AutoSize  = true;
            lblDetailPurchases.Name      = "lblDetailPurchases";

            pnlDetail.Controls.Add(UITheme.MakeDivider(22, 256, 330));

            // Purchase history list
            lblDetailHistHead.Text      = "RECENT PURCHASES (up to 8)";
            lblDetailHistHead.Font      = UITheme.FontLabel;
            lblDetailHistHead.ForeColor = UITheme.Primary;
            lblDetailHistHead.Location  = new Point(22, 268);
            lblDetailHistHead.AutoSize  = true;

            lstDetailHistory.Location    = new Point(22, 288);
            lstDetailHistory.Size        = new Size(334, 152);
            lstDetailHistory.Font        = new Font("Segoe UI", 8.5F);
            lstDetailHistory.BorderStyle = BorderStyle.FixedSingle;
            lstDetailHistory.BackColor   = UITheme.Surface;
            lstDetailHistory.ForeColor   = UITheme.TextPrimary;
            lstDetailHistory.Name        = "lstDetailHistory";

            // Delete User button
            btnDeleteUser.Text     = "Delete This Account";
            btnDeleteUser.Location = new Point(22, 452);
            btnDeleteUser.Size     = new Size(334, 36);
            btnDeleteUser.Enabled  = false;
            btnDeleteUser.Click   += btnDeleteUser_Click;
            UITheme.StyleButton(btnDeleteUser, UITheme.Danger,
                Color.FromArgb(185, 28, 28),
                font: new Font("Segoe UI Semibold", 9.5F));

            pnlDetail.Controls.AddRange(new Control[]
            {
                detailAccent, lblDetailHead,
                lblDetailUsername, lblDetailRoleBadge,
                lblDetailEmail, lblDetailRole,
                lblDetailPurchases, lblDetailHistHead, lstDetailHistory,
                btnDeleteUser
            });

            // ── Footer (626‒660) ───────────────────────────────────────────────
            pnlFooter.Location  = new Point(0, 626);
            pnlFooter.Size      = new Size(960, 34);
            pnlFooter.BackColor = UITheme.Surface;
            pnlFooter.Controls.Add(UITheme.MakeDivider(0, 0, 960));

            lblCount.Text      = string.Empty;
            lblCount.Location  = new Point(18, 10);
            lblCount.AutoSize  = true;
            lblCount.Font      = UITheme.FontSmall;
            lblCount.ForeColor = UITheme.TextSecondary;
            lblCount.Name      = "lblCount";

            lblStatus.Text      = string.Empty;
            lblStatus.Location  = new Point(280, 10);
            lblStatus.Size      = new Size(500, 18);
            lblStatus.AutoSize  = false;
            lblStatus.Font      = UITheme.FontSmall;
            lblStatus.Name      = "lblStatus";

            pnlFooter.Controls.AddRange(new Control[] { lblCount, lblStatus });

            this.Controls.AddRange(new Control[]
            {
                pnlHeader, pnlToolbar,
                pnlGrid, splitter, pnlDetail,
                pnlFooter
            });
            this.ResumeLayout(false);
        }
    }
}

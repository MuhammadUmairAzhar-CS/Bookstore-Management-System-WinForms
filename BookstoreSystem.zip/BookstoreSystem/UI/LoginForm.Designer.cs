// [FILE PATH: BookstoreSystem3Tier/UI/LoginForm.Designer.cs]
// ─────────────────────────────────────────────────────────────────────────────
// FIXED: Use ClientSize (not Size) so client area = declared dimensions.
//        Sign-up panel now uses explicit per-group y positions — no more
//        hint/confirm overlap. Password Show/Hide toggles on all pwd fields.
// ─────────────────────────────────────────────────────────────────────────────

namespace UI
{
    partial class LoginForm
    {
        private System.ComponentModel.IContainer components = null;

        private Panel     pnlBrand;
        private Label     lblBrandTitle;
        private Label     lblBrandSub;
        private Panel     pnlContent;

        // Login panel
        private Panel     pnlLogin;
        private Label     lblLoginHeading;
        private Label     lblLoginUsername;
        private TextBox   txtLoginUsername;
        private Label     lblLoginPassword;
        private TextBox   txtLoginPassword;
        private Button    btnToggleLoginPwd;
        private Label     lblLoginRole;
        private ComboBox  cmbLoginRole;
        private Button    btnLogin;
        private Button    btnForgotPassword;
        private LinkLabel lnkGoToSignUp;

        // Sign-up panel
        private Panel     pnlSignUp;
        private Label     lblSignUpHeading;
        private Label     lblSignUpUsername;
        private TextBox   txtSignUpUsername;
        private Label     lblSignUpPassword;
        private TextBox   txtSignUpPassword;
        private Button    btnToggleSignUpPwd;
        private Label     lblPasswordHint;
        private Label     lblSignUpConfirm;
        private TextBox   txtSignUpConfirm;
        private Button    btnToggleSignUpConfirm;
        private Label     lblSignUpEmail;
        private TextBox   txtSignUpEmail;
        private Label     lblSignUpRole;
        private ComboBox  cmbSignUpRole;
        private Button    btnSignUp;
        private LinkLabel lnkGoToLogin;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.SuspendLayout();

            pnlBrand               = new Panel();
            lblBrandTitle          = new Label();
            lblBrandSub            = new Label();
            pnlContent             = new Panel();
            pnlLogin               = new Panel();
            lblLoginHeading        = new Label();
            lblLoginUsername       = new Label();
            txtLoginUsername       = new TextBox();
            lblLoginPassword       = new Label();
            txtLoginPassword       = new TextBox();
            btnToggleLoginPwd      = new Button();
            lblLoginRole           = new Label();
            cmbLoginRole           = new ComboBox();
            btnLogin               = new Button();
            btnForgotPassword      = new Button();
            lnkGoToSignUp          = new LinkLabel();
            pnlSignUp              = new Panel();
            lblSignUpHeading       = new Label();
            lblSignUpUsername      = new Label();
            txtSignUpUsername      = new TextBox();
            lblSignUpPassword      = new Label();
            txtSignUpPassword      = new TextBox();
            btnToggleSignUpPwd     = new Button();
            lblPasswordHint        = new Label();
            lblSignUpConfirm       = new Label();
            txtSignUpConfirm       = new TextBox();
            btnToggleSignUpConfirm = new Button();
            lblSignUpEmail         = new Label();
            txtSignUpEmail         = new TextBox();
            lblSignUpRole          = new Label();
            cmbSignUpRole          = new ComboBox();
            btnSignUp              = new Button();
            lnkGoToLogin           = new LinkLabel();

            // ══ FORM ══════════════════════════════════════════════════════════
            // ClientSize — the usable area is exactly 880 × 640.
            this.Text            = "Bookstore Management System — Sign In";
            this.ClientSize      = new Size(880, 640);   // ← ClientSize, not Size
            this.MinimumSize     = this.Size;
            this.StartPosition   = FormStartPosition.CenterScreen;
            this.FormBorderStyle = FormBorderStyle.FixedSingle;
            this.MaximizeBox     = false;
            this.BackColor       = UITheme.PrimaryDark;
            this.Font            = UITheme.FontBase;

            // ══ LEFT BRAND PANEL ═══════════════════════════════════════════════
            pnlBrand.Location  = new Point(0, 0);
            pnlBrand.Size      = new Size(300, 640);
            pnlBrand.BackColor = UITheme.PrimaryDark;

            var topAccent = UITheme.MakeTopStripe(300, UITheme.Accent, 5);

            var logoBox = new Panel { Location = new Point(28, 38), Size = new Size(48, 48), BackColor = UITheme.Primary };
            var logoLbl = new Label  { Text = "B", Font = new Font("Segoe UI Semibold", 22F), ForeColor = UITheme.Accent, Dock = DockStyle.Fill, TextAlign = ContentAlignment.MiddleCenter };
            logoBox.Controls.Add(logoLbl);

            lblBrandTitle.Text      = "Bookstore";
            lblBrandTitle.Font      = new Font("Segoe UI Semibold", 22F);
            lblBrandTitle.ForeColor = Color.White;
            lblBrandTitle.Location  = new Point(28, 98);
            lblBrandTitle.AutoSize  = true;

            lblBrandSub.Text      = "Management System";
            lblBrandSub.Font      = new Font("Segoe UI", 11F);
            lblBrandSub.ForeColor = Color.FromArgb(155, 195, 240);
            lblBrandSub.Location  = new Point(28, 132);
            lblBrandSub.AutoSize  = true;

            pnlBrand.Controls.AddRange(new Control[] { topAccent, logoBox, lblBrandTitle, lblBrandSub });
            pnlBrand.Controls.Add(UITheme.MakeDivider(28, 172, 242));

            var tagline = new Label { Text = "Your complete platform for\r\nbookstore catalogue management.", Font = new Font("Segoe UI", 9.5F), ForeColor = Color.FromArgb(175, 210, 245), Location = new Point(28, 188), Size = new Size(242, 44) };
            pnlBrand.Controls.Add(tagline);

            var featHead = UITheme.MakeSectionLabel("FEATURES", 28, 248);
            featHead.ForeColor = Color.FromArgb(95, 140, 200);
            pnlBrand.Controls.Add(featHead);

            int fy = 266;
            foreach (var (txt, col) in new (string, Color)[]
            {
                ("Browse the full catalogue",       UITheme.Accent),
                ("Purchase books & track spending", UITheme.Success),
                ("Complete transaction history",    Color.FromArgb(99, 179, 255)),
                ("Admin: add or remove titles",     UITheme.Accent),
            })
            {
                pnlBrand.Controls.Add(new Panel { Location = new Point(28, fy + 8), Size = new Size(7, 7), BackColor = col });
                pnlBrand.Controls.Add(new Label { Text = txt, Font = new Font("Segoe UI", 9F), ForeColor = Color.FromArgb(190, 218, 242), Location = new Point(44, fy + 1), AutoSize = true });
                fy += 28;
            }

            pnlBrand.Controls.Add(UITheme.MakeDivider(28, 390, 242));
            var accTypes = UITheme.MakeSectionLabel("ACCOUNT TYPES", 28, 402);
            accTypes.ForeColor = Color.FromArgb(95, 140, 200);
            pnlBrand.Controls.Add(accTypes);
            pnlBrand.Controls.Add(new Label { Text = "User  \u2014  Browse and purchase books",    Font = new Font("Segoe UI", 8.5F), ForeColor = Color.FromArgb(175, 210, 245), Location = new Point(28, 420), AutoSize = true });
            pnlBrand.Controls.Add(new Label { Text = "Admin \u2014  Full catalogue management",    Font = new Font("Segoe UI", 8.5F), ForeColor = Color.FromArgb(175, 210, 245), Location = new Point(28, 440), AutoSize = true });
            pnlBrand.Controls.Add(new Label { Text = "v2.0  \u2022  .NET 8 Windows Forms",         Font = UITheme.FontSmall,           ForeColor = Color.FromArgb(65, 100, 150), Location = new Point(28, 606), AutoSize = true });

            // ══ RIGHT CONTENT HOST ════════════════════════════════════════════
            pnlContent.Location  = new Point(300, 0);
            pnlContent.Size      = new Size(580, 640);
            pnlContent.BackColor = Color.White;
            pnlContent.Controls.Add(UITheme.MakeTopStripe(580, UITheme.Primary, 5));

            // ─────────────────────────────────────────────────────────────────
            // SIGN-IN PANEL
            // All y positions are explicit so nothing overlaps or clips.
            // ─────────────────────────────────────────────────────────────────
            pnlLogin.Location  = new Point(0, 0);
            pnlLogin.Size      = new Size(580, 640);
            pnlLogin.BackColor = Color.White;
            pnlLogin.Visible   = true;

            const int lx = 46, lw = 488;

            // Heading
            FL(lblLoginHeading, string.Empty, 0, 0); // placeholder — set below
            lblLoginHeading.Text      = "Welcome back";
            lblLoginHeading.Font      = new Font("Segoe UI Light", 26F);
            lblLoginHeading.ForeColor = UITheme.TextPrimary;
            lblLoginHeading.Location  = new Point(lx, 36);
            lblLoginHeading.AutoSize  = true;

            var loginSubhead = new Label { Text = "Sign in to your account to continue", Font = new Font("Segoe UI", 10F), ForeColor = UITheme.TextSecondary, Location = new Point(lx, 80), AutoSize = true };
            pnlLogin.Controls.Add(UITheme.MakeDivider(lx, 112, lw));

            // Field 1: Username  y=126
            FL(lblLoginUsername, "USERNAME OR EMAIL", lx, 126);
            TX(txtLoginUsername, "txtLoginUsername",   lx, 146, lw);

            // Field 2: Password  y=198
            FL(lblLoginPassword, "PASSWORD", lx, 198);
            TX(txtLoginPassword, "txtLoginPassword", lx, 218, lw - 82, pwd: true);
            ToggleBtn(btnToggleLoginPwd, "Show", lx + lw - 76, 218);
            btnToggleLoginPwd.Click += btnToggleLoginPwd_Click;

            // Field 3: Role  y=270
            FL(lblLoginRole, "SIGN IN AS", lx, 270);
            CB(cmbLoginRole, "cmbLoginRole", lx, 290, lw, new[] { "User", "Admin" });

            // Sign In button  y=344
            btnLogin.Text     = "Sign In  \u2192";
            btnLogin.Location = new Point(lx, 344);
            btnLogin.Size     = new Size(lw, 50);
            btnLogin.Click   += btnLogin_Click;
            UITheme.StyleButton(btnLogin, UITheme.Primary, UITheme.PrimaryLight,
                font: new Font("Segoe UI Semibold", 12F));

            // Forgot password  y=406
            btnForgotPassword.Text      = "Forgot your password?";
            btnForgotPassword.Location  = new Point(lx, 406);
            btnForgotPassword.AutoSize  = true;
            btnForgotPassword.FlatStyle = FlatStyle.Flat;
            btnForgotPassword.BackColor = Color.Transparent;
            btnForgotPassword.ForeColor = UITheme.Info;
            btnForgotPassword.Font      = new Font("Segoe UI", 9F);
            btnForgotPassword.Cursor    = Cursors.Hand;
            btnForgotPassword.FlatAppearance.BorderSize         = 0;
            btnForgotPassword.FlatAppearance.MouseOverBackColor = Color.Transparent;
            btnForgotPassword.Click += btnForgotPassword_Click;

            pnlLogin.Controls.Add(UITheme.MakeDivider(lx, 436, lw));

            var noAccLbl = new Label { Text = "Don't have an account yet?", Font = new Font("Segoe UI", 9.5F), ForeColor = UITheme.TextSecondary, Location = new Point(lx, 452), AutoSize = true };
            lnkGoToSignUp.Text            = "Create a free account  \u2192";
            lnkGoToSignUp.Location        = new Point(lx + 228, 452);
            lnkGoToSignUp.AutoSize        = true;
            lnkGoToSignUp.Font            = new Font("Segoe UI Semibold", 9.5F);
            lnkGoToSignUp.LinkColor       = UITheme.Primary;
            lnkGoToSignUp.ActiveLinkColor = UITheme.PrimaryLight;
            lnkGoToSignUp.LinkClicked    += lnkGoToSignUp_LinkClicked;

            pnlLogin.Controls.AddRange(new Control[]
            {
                lblLoginHeading, loginSubhead,
                lblLoginUsername, txtLoginUsername,
                lblLoginPassword, txtLoginPassword, btnToggleLoginPwd,
                lblLoginRole,     cmbLoginRole,
                btnLogin, btnForgotPassword, noAccLbl, lnkGoToSignUp
            });

            // ─────────────────────────────────────────────────────────────────
            // SIGN-UP PANEL
            // Every group uses explicit y positions — no formula arithmetic that
            // caused the hint/confirm overlap in the previous version.
            //
            //  Heading         y = 22
            //  Subhead         y = 66
            //  Divider         y = 98
            //  [G1] Username   label=112  input=132  bottom=168
            //  [G2] Password   label=180  input=200  bottom=236  hint=240 bottom=256
            //  [G3] Confirm    label=268  input=288  bottom=324
            //  [G4] Email      label=336  input=356  bottom=392
            //  [G5] Role       label=404  combo=424  bottom=460
            //  Button          y=476  bottom=526
            //  Divider         y=538
            //  Footer          y=554
            // ─────────────────────────────────────────────────────────────────
            pnlSignUp.Location  = new Point(0, 0);
            pnlSignUp.Size      = new Size(580, 640);
            pnlSignUp.BackColor = Color.White;
            pnlSignUp.Visible   = false;

            const int sx = 46, sw = 488;

            var suHeading = new Label { Text = "Create your account", Font = new Font("Segoe UI Light", 26F), ForeColor = UITheme.TextPrimary, Location = new Point(sx, 22), AutoSize = true };
            var suSubhead = new Label { Text = "Fill in the details below to get started", Font = new Font("Segoe UI", 10F), ForeColor = UITheme.TextSecondary, Location = new Point(sx, 66), AutoSize = true };
            pnlSignUp.Controls.Add(UITheme.MakeDivider(sx, 98, sw));

            // [G1] Username — label:112  input:132
            FL(lblSignUpUsername, "CHOOSE A USERNAME", sx, 112);
            TX(txtSignUpUsername, "txtSignUpUsername", sx, 132, sw);

            // [G2] Password — label:180  input:200  hint:240
            FL(lblSignUpPassword, "PASSWORD", sx, 180);
            TX(txtSignUpPassword, "txtSignUpPassword", sx, 200, sw - 82, pwd: true);
            ToggleBtn(btnToggleSignUpPwd, "Show", sx + sw - 76, 200);
            btnToggleSignUpPwd.Click += btnToggleSignUpPwd_Click;

            lblPasswordHint.Text      = "Min 8 characters \u2014 include a number or symbol";
            lblPasswordHint.Location  = new Point(sx, 240);
            lblPasswordHint.Size      = new Size(sw, 16);
            lblPasswordHint.AutoSize  = false;
            lblPasswordHint.Font      = new Font("Segoe UI", 8F, FontStyle.Italic);
            lblPasswordHint.ForeColor = UITheme.TextMuted;

            // [G3] Confirm — label:268  input:288  (14px gap after hint bottom=256)
            FL(lblSignUpConfirm, "CONFIRM PASSWORD", sx, 268);
            TX(txtSignUpConfirm, "txtSignUpConfirm", sx, 288, sw - 82, pwd: true);
            ToggleBtn(btnToggleSignUpConfirm, "Show", sx + sw - 76, 288);
            btnToggleSignUpConfirm.Click += btnToggleSignUpConfirm_Click;

            // [G4] Email — label:336  input:356
            FL(lblSignUpEmail, "EMAIL ADDRESS", sx, 336);
            TX(txtSignUpEmail, "txtSignUpEmail", sx, 356, sw);

            // [G5] Role — label:404  combo:424
            FL(lblSignUpRole, "ACCOUNT TYPE", sx, 404);
            CB(cmbSignUpRole, "cmbSignUpRole", sx, 424, sw, new[] { "User", "Admin" });

            // Button — y:476
            btnSignUp.Text     = "Create My Account  \u2192";
            btnSignUp.Location = new Point(sx, 476);
            btnSignUp.Size     = new Size(sw, 50);
            btnSignUp.Click   += btnSignUp_Click;
            UITheme.StyleButton(btnSignUp, UITheme.Primary, UITheme.PrimaryLight,
                font: new Font("Segoe UI Semibold", 12F));

            pnlSignUp.Controls.Add(UITheme.MakeDivider(sx, 538, sw));

            var haveAccLbl = new Label { Text = "Already have an account?", Font = new Font("Segoe UI", 9.5F), ForeColor = UITheme.TextSecondary, Location = new Point(sx, 554), AutoSize = true };
            lnkGoToLogin.Text            = "Sign in here  \u2192";
            lnkGoToLogin.Location        = new Point(sx + 214, 554);
            lnkGoToLogin.AutoSize        = true;
            lnkGoToLogin.Font            = new Font("Segoe UI Semibold", 9.5F);
            lnkGoToLogin.LinkColor       = UITheme.Primary;
            lnkGoToLogin.ActiveLinkColor = UITheme.PrimaryLight;
            lnkGoToLogin.LinkClicked    += lnkGoToLogin_LinkClicked;

            pnlSignUp.Controls.AddRange(new Control[]
            {
                suHeading, suSubhead,
                lblSignUpUsername, txtSignUpUsername,
                lblSignUpPassword, txtSignUpPassword, btnToggleSignUpPwd, lblPasswordHint,
                lblSignUpConfirm,  txtSignUpConfirm,  btnToggleSignUpConfirm,
                lblSignUpEmail,    txtSignUpEmail,
                lblSignUpRole,     cmbSignUpRole,
                btnSignUp, haveAccLbl, lnkGoToLogin
            });

            pnlContent.Controls.Add(pnlLogin);
            pnlContent.Controls.Add(pnlSignUp);
            this.Controls.AddRange(new Control[] { pnlBrand, pnlContent });
            this.ResumeLayout(false);
        }

        // ── Layout helpers ────────────────────────────────────────────────────
        private static void FL(Label l, string t, int x, int y)
        {
            l.Text      = t;
            l.Font      = UITheme.FontLabel;
            l.ForeColor = UITheme.TextSecondary;
            l.Location  = new Point(x, y);
            l.AutoSize  = true;
        }

        private static void TX(TextBox t, string n, int x, int y, int w, bool pwd = false)
        {
            t.Name        = n;
            t.Location    = new Point(x, y);
            t.Size        = new Size(w, 36);
            t.Font        = UITheme.FontBase;
            t.BorderStyle = BorderStyle.FixedSingle;
            t.BackColor   = UITheme.Surface;
            t.ForeColor   = UITheme.TextPrimary;
            if (pwd) t.UseSystemPasswordChar = true;
        }

        private static void CB(ComboBox c, string n, int x, int y, int w, string[] items)
        {
            c.Name          = n;
            c.Location      = new Point(x, y);
            c.Size          = new Size(w, 36);
            c.DropDownStyle = ComboBoxStyle.DropDownList;
            c.Items.AddRange(items);
            c.SelectedIndex = 0;
            c.Font          = UITheme.FontBase;
            c.FlatStyle     = FlatStyle.Flat;
            c.BackColor     = UITheme.Surface;
        }

        private static void ToggleBtn(Button btn, string text, int x, int y)
        {
            btn.Text      = text;
            btn.Location  = new Point(x, y);
            btn.Size      = new Size(76, 36);
            btn.Cursor    = Cursors.Hand;
            btn.FlatStyle = FlatStyle.Flat;
            btn.BackColor = UITheme.Surface;
            btn.ForeColor = UITheme.Primary;
            btn.Font      = new Font("Segoe UI Semibold", 8.5F);
            btn.FlatAppearance.BorderColor        = UITheme.Border;
            btn.FlatAppearance.BorderSize         = 1;
            btn.FlatAppearance.MouseOverBackColor = UITheme.PrimaryPale;
        }
    }
}

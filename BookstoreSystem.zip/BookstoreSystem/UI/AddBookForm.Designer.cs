// [FILE PATH: BookstoreSystem3Tier/UI/AddBookForm.Designer.cs]
// FIXED: ClientSize so guidance card at the bottom is never clipped.

namespace UI
{
    partial class AddBookForm
    {
        private System.ComponentModel.IContainer components = null;
        private Panel    pnlHeader;
        private Panel    pnlBody;
        private Label    lblFormTitle;
        private Label    lblSubtitle;
        private Label    lblTitle;
        private TextBox  txtTitle;
        private Label    lblAuthor;
        private TextBox  txtAuthor;
        private Label    lblPrice;
        private TextBox  txtPrice;
        private Label    lblGenre;
        private ComboBox cmbGenre;
        private Button   btnSave;
        private Button   btnClear;
        private Label    lblStatus;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            pnlHeader = new Panel();    pnlBody   = new Panel();
            lblFormTitle = new Label(); lblSubtitle = new Label();
            lblTitle  = new Label();    txtTitle  = new TextBox();
            lblAuthor = new Label();    txtAuthor = new TextBox();
            lblPrice  = new Label();    txtPrice  = new TextBox();
            lblGenre  = new Label();    cmbGenre  = new ComboBox();
            btnSave   = new Button();   btnClear  = new Button();
            lblStatus = new Label();

            this.SuspendLayout();

            this.Text            = "Add New Book — Admin";
            this.ClientSize      = new Size(540, 590);   // ← ClientSize
            this.StartPosition   = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox     = false;
            this.BackColor       = UITheme.Surface;
            this.Font            = UITheme.FontBase;

            // Header (0‒70)
            pnlHeader.Location  = new Point(0, 0);
            pnlHeader.Size      = new Size(540, 70);
            pnlHeader.BackColor = UITheme.Primary;

            var badge = UITheme.MakeBadge("ADMIN ONLY", Color.FromArgb(40, 0, 0, 0), Color.FromArgb(255, 240, 190));
            badge.Location = new Point(452, 16);

            lblFormTitle.Text      = "Add New Book";
            lblFormTitle.Font      = new Font("Segoe UI Semibold", 17F);
            lblFormTitle.ForeColor = Color.White;
            lblFormTitle.Location  = new Point(22, 10);
            lblFormTitle.AutoSize  = true;

            lblSubtitle.Text      = "Fill in all fields below to add a book to the catalogue";
            lblSubtitle.Font      = new Font("Segoe UI", 8.5F, FontStyle.Italic);
            lblSubtitle.ForeColor = Color.FromArgb(160, 200, 250);
            lblSubtitle.Location  = new Point(22, 46);
            lblSubtitle.AutoSize  = true;

            pnlHeader.Controls.AddRange(new Control[]
                { UITheme.MakeTopStripe(540, UITheme.Accent, 4), badge, lblFormTitle, lblSubtitle });

            // Body (70‒590) — 520 px of work area
            pnlBody.Location  = new Point(0, 70);
            pnlBody.Size      = new Size(540, 520);
            pnlBody.BackColor = Color.White;

            // All y values are relative to pnlBody.
            // Each field group = label (14px) + 8px gap + input (36px) + 14px gap = 72px
            // With explicit positions:
            //   [G1] Title:  label=20   input=40  bottom=76
            //   [G2] Author: label=90   input=110 bottom=146
            //   [G3] Price:  label=160  input=180 bottom=216  hint=220 bottom=234
            //   [G4] Genre:  label=248  combo=268 bottom=304
            //   Divider:     y=318
            //   Save btn:    y=328  h=46  bottom=374
            //   Clear btn:   y=382  h=36  bottom=418
            //   Status:      y=428
            //   Info card:   y=446  h=62  bottom=508  (fits in 520)

            const int bx = 28, bw = 484;

            FL(lblTitle,  "BOOK TITLE",   bx, 20);  TX(txtTitle,  "txtTitle",  bx, 40,  bw);
            FL(lblAuthor, "AUTHOR NAME",  bx, 90);  TX(txtAuthor, "txtAuthor", bx, 110, bw);
            FL(lblPrice,  "PRICE (USD)",  bx, 160); TX(txtPrice,  "txtPrice",  bx, 180, bw);
            txtPrice.KeyPress += txtPrice_KeyPress;

            var priceHint = new Label { Text = "Enter a decimal number, e.g. 14.99", Font = UITheme.FontHint, ForeColor = UITheme.TextMuted, Location = new Point(bx, 220), AutoSize = true };

            FL(lblGenre, "GENRE / CATEGORY", bx, 248);
            cmbGenre.Location = new Point(bx, 268); cmbGenre.Size = new Size(bw, 36);
            cmbGenre.DropDownStyle = ComboBoxStyle.DropDownList;
            cmbGenre.Items.AddRange(new object[] { "Action", "Fiction", "NonFiction", "Horror", "Manga" });
            cmbGenre.SelectedIndex = 0; cmbGenre.Font = UITheme.FontBase;
            cmbGenre.FlatStyle = FlatStyle.Flat; cmbGenre.BackColor = UITheme.Surface;
            cmbGenre.Name = "cmbGenre";

            pnlBody.Controls.Add(UITheme.MakeDivider(bx, 318, bw));

            btnSave.Text = "Save Book to Catalogue"; btnSave.Location = new Point(bx, 328); btnSave.Size = new Size(bw, 46);
            btnSave.Click += btnSave_Click;
            UITheme.StyleButton(btnSave, UITheme.Primary, UITheme.PrimaryLight, font: new Font("Segoe UI Semibold", 10.5F));

            btnClear.Text = "Clear All Fields"; btnClear.Location = new Point(bx, 382); btnClear.Size = new Size(bw, 36);
            btnClear.Click += btnClear_Click;
            UITheme.StyleOutlineButton(btnClear, UITheme.TextSecondary);

            lblStatus.Text = string.Empty; lblStatus.Location = new Point(bx, 428); lblStatus.Size = new Size(bw, 18);
            lblStatus.AutoSize = false; lblStatus.Font = UITheme.FontHint; lblStatus.ForeColor = UITheme.TextMuted; lblStatus.Name = "lblStatus";

            var card = UITheme.MakeInfoCard(bx, 446, bw, 62, "WHERE WILL THIS BOOK BE SAVED?",
                "The book is added to its genre catalogue and the master book list — visible in Browse Inventory immediately.",
                UITheme.Primary, UITheme.PrimaryPale);

            pnlBody.Controls.AddRange(new Control[]
            {
                lblTitle, txtTitle, lblAuthor, txtAuthor,
                lblPrice, txtPrice, priceHint, lblGenre, cmbGenre,
                btnSave, btnClear, lblStatus, card
            });

            this.Controls.AddRange(new Control[] { pnlHeader, pnlBody });
            this.ResumeLayout(false);
        }

        private static void FL(Label l, string t, int x, int y)
        { l.Text = t; l.Font = UITheme.FontLabel; l.ForeColor = UITheme.TextSecondary; l.Location = new Point(x, y); l.AutoSize = true; }

        private static void TX(TextBox t, string n, int x, int y, int w)
        { t.Name = n; t.Location = new Point(x, y); t.Size = new Size(w, 36); t.Font = UITheme.FontBase; t.BorderStyle = BorderStyle.FixedSingle; t.BackColor = UITheme.Surface; t.ForeColor = UITheme.TextPrimary; }
    }
}

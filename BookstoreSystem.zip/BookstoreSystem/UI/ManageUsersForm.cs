// [FILE PATH: BookstoreSystem3Tier/UI/ManageUsersForm.cs]
// ─────────────────────────────────────────────────────────────────────────────
// UI LAYER — Manage User Accounts Form (Admin action)
// Left panel: DataGridView with all accounts (User and Admin roles).
// Right panel: Detailed information card for the selected account.
//   Shows username, email, role, total purchases, total spend,
//   and the 5 most recent purchases.
// Toolbar: Create New User, Delete Selected, Refresh.
// ─────────────────────────────────────────────────────────────────────────────

using BL.Services;
using DL;

namespace UI
{
    public partial class ManageUsersForm : Form
    {
        // Shadow copy of what is loaded into the grid
        private List<UserRecord> _allUsers = new();

        public ManageUsersForm()
        {
            InitializeComponent();
            LoadUsers();
        }

        // ── Data loading ──────────────────────────────────────────────────────
        private void LoadUsers()
        {
            _allUsers = AdminUserService.ListAllAccounts();

            dgvUsers.Rows.Clear();

            foreach (var u in _allUsers)
            {
                var (count, spent) = AdminUserService.GetUserStats(u.Username);
                dgvUsers.Rows.Add(
                    u.Username,
                    u.Email,
                    u.Role,
                    count,
                    spent > 0 ? $"${spent:F2}" : "—");
            }

            lblCount.Text = $"{_allUsers.Count} account(s) loaded";
            ClearDetailPanel();
        }

        private void btnRefresh_Click(object sender, EventArgs e)
        {
            LoadUsers();
            lblStatus.Text      = "Account list refreshed.";
            lblStatus.ForeColor = UITheme.TextMuted;
        }

        // ── Row selection — populate detail panel ─────────────────────────────
        private void dgvUsers_SelectionChanged(object sender, EventArgs e)
        {
            if (dgvUsers.CurrentRow is null) { ClearDetailPanel(); return; }
            int idx = dgvUsers.CurrentRow.Index;
            if (idx < 0 || idx >= _allUsers.Count) { ClearDetailPanel(); return; }

            var user = _allUsers[idx];
            ShowDetailPanel(user);
        }

        private void ShowDetailPanel(UserRecord user)
        {
            lblDetailUsername.Text  = user.Username;
            lblDetailEmail.Text     = user.Email;
            lblDetailRole.Text      = user.Role;

            lblDetailRoleBadge.Text      = user.Role.ToUpper();
            lblDetailRoleBadge.BackColor = user.Role == "Admin"
                ? UITheme.AdminColor
                : UITheme.Primary;

            var (count, spent) = AdminUserService.GetUserStats(user.Username);
            lblDetailPurchases.Text = $"{count} purchase(s)   Total: ${spent:F2}";

            // Recent purchases list
            lstDetailHistory.Items.Clear();
            var history = AdminUserService.GetUserPurchaseHistory(user.Username);

            if (history.Count == 0)
            {
                lstDetailHistory.Items.Add("No purchase records found.");
            }
            else
            {
                foreach (var (when, title, qty, unit, total) in history.Take(8))
                    lstDetailHistory.Items.Add(
                        $"{when:yyyy-MM-dd}  {title}  ×{qty}  ${total:F2}");
            }

            pnlDetail.Visible      = true;
            btnDeleteUser.Enabled  = true;
            btnDeleteUser.Tag      = user;
        }

        private void ClearDetailPanel()
        {
            pnlDetail.Visible     = false;
            btnDeleteUser.Enabled = false;
            btnDeleteUser.Tag     = null;
        }

        // ── Create New User ───────────────────────────────────────────────────
        private void btnCreateUser_Click(object sender, EventArgs e)
        {
            using var f = new CreateUserForm();
            f.ShowDialog(this);

            if (f.AccountCreated)
            {
                LoadUsers();
                lblStatus.Text      = "New account created and list refreshed.";
                lblStatus.ForeColor = UITheme.Success;
            }
        }

        // ── Delete Selected User ──────────────────────────────────────────────
        private void btnDeleteUser_Click(object sender, EventArgs e)
        {
            if (btnDeleteUser.Tag is not UserRecord user) return;

            var confirm = MessageBox.Show(
                $"Permanently delete the account:\n\n" +
                $"Username: {user.Username}\n" +
                $"Email:    {user.Email}\n" +
                $"Role:     {user.Role}\n\n" +
                $"Purchase history records are kept for audit.\n" +
                $"This action cannot be undone.",
                "Confirm Account Deletion",
                MessageBoxButtons.YesNo, MessageBoxIcon.Warning);

            if (confirm != DialogResult.Yes) return;

            var result = AdminUserService.DeleteUser(user.Username, user.Role);

            if (result.Success)
            {
                lblStatus.Text      = result.Message;
                lblStatus.ForeColor = UITheme.Success;
                LoadUsers();
            }
            else
            {
                lblStatus.Text      = result.Message;
                lblStatus.ForeColor = UITheme.Danger;
            }
        }

        // ── Live search / filter ──────────────────────────────────────────────
        private void txtSearch_TextChanged(object sender, EventArgs e)
        {
            string q = txtSearch.Text.Trim().ToLowerInvariant();

            for (int i = 0; i < dgvUsers.Rows.Count; i++)
            {
                var row      = dgvUsers.Rows[i];
                string uname = (row.Cells["colUsername"].Value?.ToString() ?? "").ToLowerInvariant();
                string email = (row.Cells["colEmail"].Value?.ToString()    ?? "").ToLowerInvariant();
                string role  = (row.Cells["colRole"].Value?.ToString()     ?? "").ToLowerInvariant();

                row.Visible = string.IsNullOrEmpty(q)
                    || uname.Contains(q)
                    || email.Contains(q)
                    || role.Contains(q);
            }
        }

        // ── Role filter ───────────────────────────────────────────────────────
        private void cmbRoleFilter_SelectedIndexChanged(object sender, EventArgs e)
        {
            string filter = cmbRoleFilter.SelectedItem?.ToString() ?? "All Roles";

            for (int i = 0; i < dgvUsers.Rows.Count; i++)
            {
                var row  = dgvUsers.Rows[i];
                string r = (row.Cells["colRole"].Value?.ToString() ?? "");
                row.Visible = filter == "All Roles"
                    || r.Equals(filter, StringComparison.OrdinalIgnoreCase);
            }
        }
    }
}

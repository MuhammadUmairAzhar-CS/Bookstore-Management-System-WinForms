// [FILE PATH: BookstoreSystem3Tier/UI/UITheme.cs]
// ─────────────────────────────────────────────────────────────────────────────
// UI LAYER — Centralized Design System (Professional Blue Edition)
// All colours, fonts, and reusable style helpers live here so every form
// stays visually consistent without duplicating layout code.
// ─────────────────────────────────────────────────────────────────────────────

namespace UI
{
    public static class UITheme
    {
        // ── Brand Palette — Professional Blue ────────────────────────────────
        public static readonly Color PrimaryDark   = Color.FromArgb(13, 32, 72);     // deep navy
        public static readonly Color Primary       = Color.FromArgb(26, 60, 130);    // rich blue
        public static readonly Color PrimaryLight  = Color.FromArgb(49, 97, 184);    // medium blue
        public static readonly Color PrimaryPale   = Color.FromArgb(219, 232, 255);  // pale blue tint
        public static readonly Color Accent        = Color.FromArgb(250, 180, 20);   // gold accent

        public static readonly Color Success       = Color.FromArgb(22, 163, 74);
        public static readonly Color SuccessLight  = Color.FromArgb(240, 253, 244);
        public static readonly Color Danger        = Color.FromArgb(220, 38, 38);
        public static readonly Color DangerLight   = Color.FromArgb(254, 242, 242);
        public static readonly Color Warning       = Color.FromArgb(202, 108, 0);
        public static readonly Color WarningLight  = Color.FromArgb(255, 247, 230);
        public static readonly Color Info          = Color.FromArgb(37, 127, 204);
        public static readonly Color InfoLight     = Color.FromArgb(235, 245, 255);

        // ── Neutrals ──────────────────────────────────────────────────────────
        public static readonly Color Surface       = Color.FromArgb(244, 247, 252);
        public static readonly Color White         = Color.White;
        public static readonly Color Border        = Color.FromArgb(208, 220, 240);
        public static readonly Color TextPrimary   = Color.FromArgb(10, 18, 40);
        public static readonly Color TextSecondary = Color.FromArgb(65, 82, 115);
        public static readonly Color TextMuted     = Color.FromArgb(140, 158, 190);
        public static readonly Color Divider       = Color.FromArgb(218, 228, 244);

        // ── Admin highlight ───────────────────────────────────────────────────
        public static readonly Color AdminColor    = Color.FromArgb(202, 108, 0);
        public static readonly Color AdminLight    = Color.FromArgb(255, 247, 230);

        // ── Typography ────────────────────────────────────────────────────────
        public static readonly Font FontTitle    = new Font("Segoe UI Semibold", 22F);
        public static readonly Font FontXLarge   = new Font("Segoe UI Semibold", 18F);
        public static readonly Font FontLarge    = new Font("Segoe UI Semibold", 14F);
        public static readonly Font FontBase     = new Font("Segoe UI", 10F);
        public static readonly Font FontBold     = new Font("Segoe UI Semibold", 10F);
        public static readonly Font FontSmall    = new Font("Segoe UI", 8.5F);
        public static readonly Font FontHint     = new Font("Segoe UI", 8F, FontStyle.Italic);
        public static readonly Font FontBtnNorm  = new Font("Segoe UI Semibold", 10F);
        public static readonly Font FontBtnSmall = new Font("Segoe UI Semibold", 9F);
        public static readonly Font FontLabel    = new Font("Segoe UI", 7.5F, FontStyle.Bold);
        public static readonly Font FontMono     = new Font("Consolas", 8.5F);

        // ── Style helpers ─────────────────────────────────────────────────────

        /// <summary>Styles a button with flat appearance and hover color feedback.</summary>
        public static void StyleButton(
            Button btn, Color back, Color hover,
            Color? fore = null, Font? font = null)
        {
            btn.FlatStyle   = FlatStyle.Flat;
            btn.BackColor   = back;
            btn.ForeColor   = fore ?? Color.White;
            btn.Font        = font ?? FontBtnNorm;
            btn.Cursor      = Cursors.Hand;
            btn.FlatAppearance.BorderSize         = 0;
            btn.FlatAppearance.MouseOverBackColor = hover;
        }

        /// <summary>Styles a secondary (ghost) button with a border outline.</summary>
        public static void StyleOutlineButton(Button btn, Color borderColor, Font? font = null)
        {
            btn.FlatStyle   = FlatStyle.Flat;
            btn.BackColor   = Color.White;
            btn.ForeColor   = borderColor;
            btn.Font        = font ?? FontBtnSmall;
            btn.Cursor      = Cursors.Hand;
            btn.FlatAppearance.BorderSize         = 1;
            btn.FlatAppearance.BorderColor        = borderColor;
            btn.FlatAppearance.MouseOverBackColor = Surface;
        }

        /// <summary>Applies the standard DataGridView appearance.</summary>
        public static void StyleGrid(DataGridView dgv)
        {
            dgv.BackgroundColor       = Color.White;
            dgv.BorderStyle           = BorderStyle.None;
            dgv.CellBorderStyle       = DataGridViewCellBorderStyle.SingleHorizontal;
            dgv.GridColor             = Divider;
            dgv.RowHeadersVisible     = false;
            dgv.AllowUserToAddRows    = false;
            dgv.AllowUserToDeleteRows = false;
            dgv.ReadOnly              = true;
            dgv.SelectionMode         = DataGridViewSelectionMode.FullRowSelect;
            dgv.AutoSizeColumnsMode   = DataGridViewAutoSizeColumnsMode.Fill;
            dgv.MultiSelect           = false;
            dgv.ScrollBars            = ScrollBars.Vertical;

            dgv.ColumnHeadersDefaultCellStyle.BackColor  = Surface;
            dgv.ColumnHeadersDefaultCellStyle.ForeColor  = Primary;
            dgv.ColumnHeadersDefaultCellStyle.Font       = new Font("Segoe UI Semibold", 8.5F);
            dgv.ColumnHeadersDefaultCellStyle.Padding    = new Padding(10, 0, 0, 0);
            dgv.ColumnHeadersHeight                      = 36;
            dgv.ColumnHeadersHeightSizeMode              = DataGridViewColumnHeadersHeightSizeMode.DisableResizing;
            dgv.ColumnHeadersBorderStyle                 = DataGridViewHeaderBorderStyle.None;
            dgv.EnableHeadersVisualStyles                = false;

            dgv.DefaultCellStyle.BackColor             = Color.White;
            dgv.DefaultCellStyle.ForeColor             = TextPrimary;
            dgv.DefaultCellStyle.Font                  = FontBase;
            dgv.DefaultCellStyle.SelectionBackColor    = PrimaryPale;
            dgv.DefaultCellStyle.SelectionForeColor    = TextPrimary;
            dgv.DefaultCellStyle.Padding               = new Padding(10, 0, 0, 0);
            dgv.RowTemplate.Height                     = 40;

            dgv.AlternatingRowsDefaultCellStyle.BackColor = Surface;
        }

        /// <summary>Creates a pill badge label.</summary>
        public static Label MakeBadge(string text, Color back, Color fore)
        {
            return new Label
            {
                Text      = text,
                Font      = new Font("Segoe UI", 7F, FontStyle.Bold),
                BackColor = back,
                ForeColor = fore,
                AutoSize  = false,
                Size      = new Size(64, 18),
                TextAlign = ContentAlignment.MiddleCenter
            };
        }

        /// <summary>Creates a top accent stripe (colored bar at top of header).</summary>
        public static Panel MakeTopStripe(int width, Color color, int height = 4)
        {
            return new Panel
            {
                Location  = new Point(0, 0),
                Size      = new Size(width, height),
                BackColor = color
            };
        }

        /// <summary>Creates an info card with a colored left accent bar.</summary>
        public static Panel MakeInfoCard(
            int x, int y, int w, int h,
            string heading, string body,
            Color accentColor, Color backColor)
        {
            var card = new Panel
            {
                Location  = new Point(x, y),
                Size      = new Size(w, h),
                BackColor = backColor
            };

            var bar = new Panel
            {
                Location  = new Point(0, 0),
                Size      = new Size(4, h),
                BackColor = accentColor
            };

            var lblH = new Label
            {
                Text      = heading,
                Font      = FontLabel,
                ForeColor = accentColor,
                Location  = new Point(14, 8),
                AutoSize  = true
            };

            var lblB = new Label
            {
                Text      = body,
                Font      = new Font("Segoe UI", 8.5F),
                ForeColor = TextSecondary,
                Location  = new Point(14, 26),
                Size      = new Size(w - 28, h - 34),
                AutoSize  = false
            };

            card.Controls.AddRange(new Control[] { bar, lblH, lblB });
            return card;
        }

        /// <summary>Creates a horizontal divider panel.</summary>
        public static Panel MakeDivider(int x, int y, int width)
        {
            return new Panel
            {
                Location  = new Point(x, y),
                Size      = new Size(width, 1),
                BackColor = Divider
            };
        }

        /// <summary>Creates a section label (all-caps small text).</summary>
        public static Label MakeSectionLabel(string text, int x, int y)
        {
            return new Label
            {
                Text      = text,
                Font      = FontLabel,
                ForeColor = TextMuted,
                Location  = new Point(x, y),
                AutoSize  = true
            };
        }
    }
}

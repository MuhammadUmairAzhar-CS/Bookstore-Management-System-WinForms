// [FILE PATH: BookstoreSystem3Tier/UI/ForgotPasswordDialog.Designer.cs]
// FIXED: ClientSize so privacy note at bottom is never clipped.

namespace UI
{
    partial class ForgotPasswordDialog
    {
        private System.ComponentModel.IContainer components = null;

        private Panel   pnlHeader;
        private Label   lblHeaderTitle;
        private Label   lblInstruction;
        private Panel   pnlFieldGroup;
        private Label   lblEmail;
        private TextBox txtEmail;
        private Label   lblRoleInfo;
        private Button  btnSubmit;
        private Button  btnCancel;
        private Panel   pnlPrivacy;

        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null)) components.Dispose();
            base.Dispose(disposing);
        }

        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.SuspendLayout();

            pnlHeader     = new Panel(); lblHeaderTitle = new Label();
            lblInstruction = new Label(); pnlFieldGroup = new Panel();
            lblEmail      = new Label(); txtEmail       = new TextBox();
            lblRoleInfo   = new Label(); btnSubmit      = new Button();
            btnCancel     = new Button(); pnlPrivacy    = new Panel();

            this.Text            = "Recover Account";
            this.ClientSize      = new Size(460, 420);   // ← ClientSize
            this.StartPosition   = FormStartPosition.CenterParent;
            this.FormBorderStyle = FormBorderStyle.FixedDialog;
            this.MaximizeBox     = false;
            this.MinimizeBox     = false;
            this.BackColor       = Color.White;
            this.Font            = UITheme.FontBase;

            // Header (0‒70)
            pnlHeader.Location  = new Point(0, 0);
            pnlHeader.Size      = new Size(460, 70);
            pnlHeader.BackColor = UITheme.PrimaryDark;
            pnlHeader.Controls.Add(UITheme.MakeTopStripe(460, UITheme.Primary, 4));

            lblHeaderTitle.Text = "Recover Account"; lblHeaderTitle.Font = new Font("Segoe UI Semibold", 17F);
            lblHeaderTitle.ForeColor = Color.White; lblHeaderTitle.Location = new Point(22, 10); lblHeaderTitle.AutoSize = true;
            pnlHeader.Controls.Add(new Label { Text = "Look up your username using your registered email address", Font = new Font("Segoe UI", 8.5F, FontStyle.Italic), ForeColor = Color.FromArgb(140, 185, 230), Location = new Point(22, 46), AutoSize = true });
            pnlHeader.Controls.Add(lblHeaderTitle);

            // Body positions:
            //   Instruction:  y=88  h=42
            //   Field group:  y=140 h=76
            //   Role info:    y=226 h=18
            //   Submit btn:   y=252 h=44  bottom=296
            //   Cancel btn:   y=264 h=24  (right-aligned alongside submit area)
            //   Divider:      y=308
            //   Privacy panel:y=320 h=82  bottom=402  (fits in 420)

            lblInstruction.Text = "Enter the email address linked to your account.\r\nWe\u2019ll look up your username for you.";
            lblInstruction.Location = new Point(28, 88); lblInstruction.Size = new Size(402, 42);
            lblInstruction.AutoSize = false; lblInstruction.Font = UITheme.FontBase; lblInstruction.ForeColor = UITheme.TextSecondary;

            pnlFieldGroup.Location = new Point(28, 140); pnlFieldGroup.Size = new Size(402, 76); pnlFieldGroup.BackColor = UITheme.Surface;
            lblEmail.Text = "REGISTERED EMAIL ADDRESS"; lblEmail.Location = new Point(14, 10);
            lblEmail.AutoSize = true; lblEmail.Font = UITheme.FontLabel; lblEmail.ForeColor = UITheme.Primary;
            txtEmail.Location = new Point(14, 30); txtEmail.Size = new Size(374, 32);
            txtEmail.Font = UITheme.FontBase; txtEmail.BorderStyle = BorderStyle.FixedSingle;
            txtEmail.BackColor = Color.White; txtEmail.ForeColor = UITheme.TextPrimary; txtEmail.Name = "txtEmail";
            pnlFieldGroup.Controls.AddRange(new Control[] { lblEmail, txtEmail });

            lblRoleInfo.Text = string.Empty; lblRoleInfo.Location = new Point(28, 226);
            lblRoleInfo.AutoSize = true; lblRoleInfo.Font = UITheme.FontHint; lblRoleInfo.ForeColor = UITheme.TextMuted; lblRoleInfo.Name = "lblRoleInfo";

            btnSubmit.Text = "Find My Account"; btnSubmit.Location = new Point(28, 252); btnSubmit.Size = new Size(192, 44);
            btnSubmit.Click += btnSubmit_Click; btnSubmit.Name = "btnSubmit";
            UITheme.StyleButton(btnSubmit, UITheme.Primary, UITheme.PrimaryLight, font: new Font("Segoe UI Semibold", 10F));

            btnCancel.Text = "\u2190 Go Back to Login"; btnCancel.Location = new Point(228, 264); btnCancel.Size = new Size(202, 24);
            btnCancel.FlatStyle = FlatStyle.Flat; btnCancel.BackColor = Color.White; btnCancel.ForeColor = UITheme.TextSecondary;
            btnCancel.Font = UITheme.FontBase; btnCancel.Cursor = Cursors.Hand; btnCancel.TextAlign = ContentAlignment.MiddleLeft;
            btnCancel.FlatAppearance.BorderSize = 0; btnCancel.FlatAppearance.MouseOverBackColor = UITheme.Surface;
            btnCancel.Click += btnCancel_Click; btnCancel.Name = "btnCancel";

            this.Controls.Add(UITheme.MakeDivider(28, 308, 402));

            // Privacy panel (y=320, h=82)
            pnlPrivacy.Location = new Point(28, 320); pnlPrivacy.Size = new Size(402, 82); pnlPrivacy.BackColor = Color.White;
            var privHead = UITheme.MakeSectionLabel("ACCOUNT INFORMATION PRIVACY", 0, 0);
            privHead.ForeColor = UITheme.Primary;
            pnlPrivacy.Controls.AddRange(new Control[]
            {
                privHead,
                new Label
                {
                    Text = "Account details are stored securely and used only to retrieve your username. " +
                           "No passwords are shown or shared at any point.",
                    Font = new Font("Segoe UI", 8.5F), ForeColor = UITheme.TextSecondary,
                    Location = new Point(0, 18), Size = new Size(402, 58), AutoSize = false
                }
            });

            this.Controls.AddRange(new Control[]
            {
                pnlHeader, lblInstruction, pnlFieldGroup, lblRoleInfo,
                btnSubmit, btnCancel, pnlPrivacy
            });

            this.ResumeLayout(false);
        }
    }
}

// [FILE PATH: BookstoreSystem3Tier/UI/LoginForm.cs]
// ─────────────────────────────────────────────────────────────────────────────
// UI LAYER — Login Form (code-behind)
// ─────────────────────────────────────────────────────────────────────────────

using BL.Services;

namespace UI
{
    public partial class LoginForm : Form
    {
        // Track visibility state per password field
        private bool _loginPwdVisible = false;
        private bool _signUpPwdVisible = false;
        private bool _signUpConfirmVisible = false;

        public LoginForm()
        {
            InitializeComponent();
        }

        // ── Login ─────────────────────────────────────────────────────────────
        private void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtLoginUsername.Text.Trim();
            string password = txtLoginPassword.Text;
            string role     = cmbLoginRole.SelectedItem?.ToString() ?? "User";

            var user = AuthService.Login(username, password, role, out string errorMessage);

            if (user is null)
            {
                ShowWarning(errorMessage);
                return;
            }

            var dashboard = new DashboardForm(user);
            dashboard.Show();
            this.Hide();
            dashboard.FormClosed += (_, _) => this.Close();
        }

        // ── Sign-up ───────────────────────────────────────────────────────────
        private void btnSignUp_Click(object sender, EventArgs e)
        {
            string username = txtSignUpUsername.Text.Trim();
            string password = txtSignUpPassword.Text;
            string confirm  = txtSignUpConfirm.Text;
            string email    = txtSignUpEmail.Text.Trim();
            string role     = cmbSignUpRole.SelectedItem?.ToString() ?? "User";

            if (password != confirm)
            {
                ShowWarning("Passwords do not match.\nPlease re-enter both password fields.");
                txtSignUpConfirm.Clear();
                txtSignUpConfirm.Focus();
                return;
            }

            var result = AuthService.Register(username, password, email, role);
            if (!result.Success)
            {
                ShowWarning(result.Message);
                return;
            }

            ShowInfo("Account created successfully!\nYou can now sign in with your new credentials.");
            ClearSignUpFields();
            ShowLoginPanel();
        }

        // ── Password visibility toggles ───────────────────────────────────────
        private void btnToggleLoginPwd_Click(object sender, EventArgs e)
        {
            _loginPwdVisible = !_loginPwdVisible;
            txtLoginPassword.UseSystemPasswordChar = !_loginPwdVisible;
            btnToggleLoginPwd.Text = _loginPwdVisible ? "Hide" : "Show";
        }

        private void btnToggleSignUpPwd_Click(object sender, EventArgs e)
        {
            _signUpPwdVisible = !_signUpPwdVisible;
            txtSignUpPassword.UseSystemPasswordChar = !_signUpPwdVisible;
            btnToggleSignUpPwd.Text = _signUpPwdVisible ? "Hide" : "Show";
        }

        private void btnToggleSignUpConfirm_Click(object sender, EventArgs e)
        {
            _signUpConfirmVisible = !_signUpConfirmVisible;
            txtSignUpConfirm.UseSystemPasswordChar = !_signUpConfirmVisible;
            btnToggleSignUpConfirm.Text = _signUpConfirmVisible ? "Hide" : "Show";
        }

        // ── Tab switching ─────────────────────────────────────────────────────
        private void lnkGoToSignUp_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
            => ShowSignUpPanel();

        private void lnkGoToLogin_LinkClicked(object sender, LinkLabelLinkClickedEventArgs e)
            => ShowLoginPanel();

        private void btnForgotPassword_Click(object sender, EventArgs e)
        {
            string role = cmbLoginRole.SelectedItem?.ToString() ?? "User";
            using var dialog = new ForgotPasswordDialog(role);
            dialog.ShowDialog(this);
        }

        // ── Helpers ───────────────────────────────────────────────────────────
        private void ShowLoginPanel()
        {
            pnlLogin.Visible  = true;
            pnlSignUp.Visible = false;
        }

        private void ShowSignUpPanel()
        {
            pnlLogin.Visible  = false;
            pnlSignUp.Visible = true;
        }

        private void ClearSignUpFields()
        {
            txtSignUpUsername.Clear();
            txtSignUpPassword.Clear();
            txtSignUpConfirm.Clear();
            txtSignUpEmail.Clear();
            cmbSignUpRole.SelectedIndex = 0;
        }

        private static void ShowWarning(string msg) =>
            MessageBox.Show(msg, "Validation Error",
                MessageBoxButtons.OK, MessageBoxIcon.Warning);

        private static void ShowInfo(string msg) =>
            MessageBox.Show(msg, "Account Created",
                MessageBoxButtons.OK, MessageBoxIcon.Information);
    }
}


using BL.Models;
using DL;

namespace BL.Validators
{
    public static class BookValidator
    {
        public static ValidationResult ValidateBook(BookRecord book)
        {
            // Guard against a null reference reaching the DL
            if (book is null)
                return ValidationResult.Fail("Book record cannot be null.");

            // ── Title ─────────────────────────────────────────────────────────
            if (string.IsNullOrWhiteSpace(book.Title))
                return ValidationResult.Fail("Book title cannot be empty.");

            if (book.Title.Length > 200)
                return ValidationResult.Fail("Book title must not exceed 200 characters.");

            // Pipe character would corrupt the flat-file format
            if (book.Title.Contains('|'))
                return ValidationResult.Fail("Book title must not contain the '|' character.");

            // ── Author ────────────────────────────────────────────────────────
            if (string.IsNullOrWhiteSpace(book.Author))
                return ValidationResult.Fail("Author name cannot be empty.");

            if (book.Author.Length > 150)
                return ValidationResult.Fail("Author name must not exceed 150 characters.");

            if (book.Author.Contains('|'))
                return ValidationResult.Fail("Author name must not contain the '|' character.");

            // ── Price ─────────────────────────────────────────────────────────
            if (book.Price < 0)
                return ValidationResult.Fail("Price cannot be negative.");

            if (book.Price > 99_999)
                return ValidationResult.Fail("Price seems unrealistically high (max $99,999).");

            // ── Genre ─────────────────────────────────────────────────────────
            if (!AppConfig.ValidGenres.Contains(book.Genre))
                return ValidationResult.Fail(
                    $"Genre must be one of: {string.Join(", ", AppConfig.ValidGenres)}.");

            return ValidationResult.Pass();
        }

        /// <summary>Validates the quantity string supplied when purchasing a book.</summary>
        public static ValidationResult ValidatePurchase(string bookTitle, string quantityText)
        {
            if (string.IsNullOrWhiteSpace(bookTitle))
                return ValidationResult.Fail("Book title cannot be empty.");

            if (string.IsNullOrWhiteSpace(quantityText))
                return ValidationResult.Fail("Quantity cannot be empty.");

            if (!int.TryParse(quantityText.Trim(), out int qty))
                return ValidationResult.Fail("Quantity must be a whole number (e.g. 1, 2, 3).");

            if (qty <= 0)
                return ValidationResult.Fail("Quantity must be greater than zero.");

            if (qty > 1_000)
                return ValidationResult.Fail("Quantity cannot exceed 1,000 per purchase.");

            return ValidationResult.Pass();
        }
    }
}

using System.Text.RegularExpressions;
using BL.Models;

namespace BL.Validators
{
    public static class UserValidator
    {
        // ── Pre-compiled regexes for performance ──────────────────────────────
        private static readonly Regex AllDigitsRegex   = new(@"^\d+$",         RegexOptions.Compiled);
        private static readonly Regex AllLettersRegex  = new(@"^[A-Za-z]+$",   RegexOptions.Compiled);
        private static readonly Regex EmailFormatRegex = new(@"^[^@\s]+@[^@\s]+\.[^@\s]+$",
                                                              RegexOptions.Compiled);

        public static ValidationResult ValidateRegistration(
            string username, string password, string email, string role)
        {
            // ── Username checks ───────────────────────────────────────────────
            if (string.IsNullOrWhiteSpace(username))
                return ValidationResult.Fail("Username cannot be empty.");

            if (username.Length < 2 || username.Length > 50)
                return ValidationResult.Fail("Username must be between 2 and 50 characters.");

            // [RULE] Reject usernames that are entirely numeric (e.g. "12345")
            if (AllDigitsRegex.IsMatch(username))
                return ValidationResult.Fail(
                    "Username cannot consist of numbers only. " +
                    "Include at least one letter (e.g. \"user42\" not \"42\").");

            if (username.Contains('|'))
                return ValidationResult.Fail("Username must not contain the '|' character.");

            // ── Password checks ───────────────────────────────────────────────
            if (string.IsNullOrWhiteSpace(password))
                return ValidationResult.Fail("Password cannot be empty.");

            if (password.Length < 4)
                return ValidationResult.Fail("Password must be at least 4 characters long.");

            // [RULE] Reject passwords that are entirely alphabetic (e.g. "abcdef")
            // A strong password must contain at least one digit or special character.
            if (AllLettersRegex.IsMatch(password))
                return ValidationResult.Fail(
                    "Password cannot consist of letters only. " +
                    "Include at least one number or special character (e.g. \"Pass1\" not \"Pass\").");

            // ── Email checks ──────────────────────────────────────────────────
            if (string.IsNullOrWhiteSpace(email))
                return ValidationResult.Fail("Email address cannot be empty.");

            if (!EmailFormatRegex.IsMatch(email))
                return ValidationResult.Fail(
                    "Email address format is invalid. Expected format: user@example.com");

            if (email.Contains('|'))
                return ValidationResult.Fail("Email must not contain the '|' character.");

            // ── Role check ────────────────────────────────────────────────────
            if (role != "User" && role != "Admin")
                return ValidationResult.Fail("Role must be either 'User' or 'Admin'.");

            return ValidationResult.Pass();
        }

        public static ValidationResult ValidateLoginInput(
            string username, string password, string role)
        {
            if (string.IsNullOrWhiteSpace(username))
                return ValidationResult.Fail("Username cannot be empty.");

            if (string.IsNullOrWhiteSpace(password))
                return ValidationResult.Fail("Password cannot be empty.");

            if (role != "User" && role != "Admin")
                return ValidationResult.Fail("Role must be either 'User' or 'Admin'.");

            return ValidationResult.Pass();
        }

        /// <summary>Validates a recovery email address before querying the DL.</summary>
        public static ValidationResult ValidateEmail(string email)
        {
            if (string.IsNullOrWhiteSpace(email))
                return ValidationResult.Fail("Email address cannot be empty.");

            if (!EmailFormatRegex.IsMatch(email))
                return ValidationResult.Fail("Email address format is invalid.");

            return ValidationResult.Pass();
        }
    }
}

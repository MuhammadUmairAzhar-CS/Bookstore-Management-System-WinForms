namespace BL.Models
{

    public sealed class ValidationResult
    {
        public bool   IsValid  { get; }
        public string Message  { get; }

        private ValidationResult(bool isValid, string message)
        {
            IsValid = isValid;
            Message = message;
        }

        public static ValidationResult Pass()
            => new(true,  "Validation passed.");


        public static ValidationResult Fail(string reason)
            => new(false, reason);
    }
}

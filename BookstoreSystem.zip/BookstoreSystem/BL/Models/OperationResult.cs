namespace BL.Models
{
    public sealed class OperationResult
    {
        public bool   Success { get; }
        public string Message { get; }

        private OperationResult(bool success, string message)
        {
            Success = success;
            Message = message;
        }
        public static OperationResult Ok(string message = "Operation successful.")
            => new(true,  message);

        public static OperationResult Fail(string message)
            => new(false, message);    
        public static OperationResult FromFileResult(DL.FileResult fileResult)
            => new(fileResult.Success, fileResult.Message);
    }
}

using BL.Models;
using BL.Validators;
using DL;

namespace BL.Services
{
    public static class AdminUserService
    {

        public static (List<UserRecord> Users, List<string> Warnings)
            ListUsers()
        {
            return UserRepository.LoadUsers(AppConfig.UserFilePath);
        }

        public static (List<UserRecord> Admins, List<string> Warnings)
            ListAdmins()
        {
            return UserRepository.LoadUsers(AppConfig.AdminFilePath);
        }

        public static List<UserRecord> ListAllAccounts()
        {
            var (users,  _) = UserRepository.LoadUsers(AppConfig.UserFilePath);
            var (admins, _) = UserRepository.LoadUsers(AppConfig.AdminFilePath);
            return users.Concat(admins).ToList();
        }

        public static List<(DateTime When, string Title, int Qty, decimal Unit, decimal Total)>
            GetUserPurchaseHistory(string username)
        {
            if (string.IsNullOrWhiteSpace(username)) return new();

            return BookService.GetPurchaseHistory()
                .Where(r => r.User.Equals(username, StringComparison.OrdinalIgnoreCase))
                .Select(r => (r.When, r.Title, r.Qty, r.Unit, r.Total))
                .OrderByDescending(r => r.When)
                .ToList();
        }


        public static (int PurchaseCount, decimal TotalSpent)
            GetUserStats(string username)
        {
            var history = GetUserPurchaseHistory(username);
            return (history.Count, history.Sum(r => r.Total));
        }

        public static OperationResult CreateUser(
            string username, string password, string confirmPassword,
            string email, string role)
        {
            // -- Basic field validation --
            var validation = UserValidator.ValidateRegistration(username, password, email, role);
            if (!validation.IsValid)
                return OperationResult.Fail(validation.Message);

            // -- Password confirmation --
            if (!password.Equals(confirmPassword, StringComparison.Ordinal))
                return OperationResult.Fail("Passwords do not match. Please re-enter both fields.");

            // -- Load existing accounts and check for duplicates --
            string filePath = role == "Admin"
                ? AppConfig.AdminFilePath
                : AppConfig.UserFilePath;

            var (users, warnings) = UserRepository.LoadUsers(filePath);
            if (warnings.Count > 0)
                return OperationResult.Fail(
                    "Could not safely read existing accounts: " + string.Join("; ", warnings));

            bool usernameTaken = users.Any(u =>
                u.Username.Equals(username, StringComparison.OrdinalIgnoreCase));
            if (usernameTaken)
                return OperationResult.Fail(
                    $"The username \"{username}\" is already in use for the {role} role.");

            bool emailTaken = users.Any(u =>
                u.Email.Equals(email, StringComparison.OrdinalIgnoreCase));
            if (emailTaken)
                return OperationResult.Fail(
                    $"An account with \"{email}\" already exists for the {role} role.");

            // -- Hash and persist --
            string hash = SecurityHelper.HashPassword(password);
            users.Add(new UserRecord(username, hash, email, role));

            var saveResult = UserRepository.SaveUsers(filePath, users);
            if (!saveResult.Success)
                return OperationResult.FromFileResult(saveResult);

            return OperationResult.Ok(
                $"Account \"{username}\" ({role}) created successfully.");
        }

        public static OperationResult DeleteUser(string username, string role)
        {
            if (string.IsNullOrWhiteSpace(username))
                return OperationResult.Fail("Username cannot be empty.");

            string filePath = role == "Admin"
                ? AppConfig.AdminFilePath
                : AppConfig.UserFilePath;

            var (users, warnings) = UserRepository.LoadUsers(filePath);
            if (warnings.Count > 0)
                return OperationResult.Fail(
                    "Could not safely read accounts: " + string.Join("; ", warnings));

            int before = users.Count;
            users.RemoveAll(u =>
                u.Username.Equals(username, StringComparison.OrdinalIgnoreCase));

            if (users.Count == before)
                return OperationResult.Fail(
                    $"No {role} account found with username \"{username}\".");

            var saveResult = UserRepository.SaveUsers(filePath, users);
            return saveResult.Success
                ? OperationResult.Ok($"Account \"{username}\" deleted.")
                : OperationResult.FromFileResult(saveResult);
        }
    }
}






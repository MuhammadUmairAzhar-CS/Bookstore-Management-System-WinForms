using BL.Models;
using BL.Validators;
using DL;

namespace BL.Services
{
    public static class AuthService
    {
        /// <param name="errorMessage">Populated when the return value is null.</param>
        public static UserRecord? Login(
            string username, string password, string role,
            out string errorMessage)
        {
            errorMessage = string.Empty;

            var validation = UserValidator.ValidateLoginInput(username, password, role);
            if (!validation.IsValid)
            {
                errorMessage = validation.Message;
                return null;
            }

            string hash = SecurityHelper.HashPassword(password);

            string filePath = role == "Admin"
                ? AppConfig.AdminFilePath
                : AppConfig.UserFilePath;

            var (users, warnings) = UserRepository.LoadUsers(filePath);

            if (warnings.Count > 0)
            {
                errorMessage = "Warning: some records could not be read — " +
                               string.Join("; ", warnings);
            }
            var user = users.FirstOrDefault(u =>
                u.Username.Equals(username, StringComparison.OrdinalIgnoreCase) &&
                u.PasswordHash == hash);

            if (user is null)
                errorMessage = "Invalid username or password for the selected role.";

            return user;
        }

 
        public static OperationResult Register(
            string username, string password, string email, string role)
        {

            var validation = UserValidator.ValidateRegistration(username, password, email, role);
            if (!validation.IsValid)
                return OperationResult.Fail(validation.Message);

            string filePath = role == "Admin"
                ? AppConfig.AdminFilePath
                : AppConfig.UserFilePath;

            var (users, warnings) = UserRepository.LoadUsers(filePath);
            if (warnings.Count > 0)
                return OperationResult.Fail(
                    "Could not safely read existing accounts: " + string.Join("; ", warnings));

            bool usernameTaken = users.Any(u =>
                u.Username.Equals(username, StringComparison.OrdinalIgnoreCase));

            if (usernameTaken)
                return OperationResult.Fail(
                    $"The username \"{username}\" is already taken for the {role} role.");

            bool emailTaken = users.Any(u =>
                u.Email.Equals(email, StringComparison.OrdinalIgnoreCase));

            if (emailTaken)
                return OperationResult.Fail(
                    $"An account with the email \"{email}\" already exists for the {role} role.");

            string hash = SecurityHelper.HashPassword(password);
            users.Add(new UserRecord(username, hash, email, role));

            var saveResult = UserRepository.SaveUsers(filePath, users);
            return OperationResult.FromFileResult(saveResult);
        }

        public static (string? Username, string ErrorMessage)
            RecoverByEmail(string email, string role)
        {

            var emailValidation = UserValidator.ValidateEmail(email);
            if (!emailValidation.IsValid)
                return (null, emailValidation.Message);

            string filePath = role == "Admin"
                ? AppConfig.AdminFilePath
                : AppConfig.UserFilePath;

            var (users, warnings) = UserRepository.LoadUsers(filePath);
            if (warnings.Count > 0)
                return (null, "Could not read user data: " + string.Join("; ", warnings));

            var user = users.FirstOrDefault(u =>
                u.Email.Equals(email, StringComparison.OrdinalIgnoreCase));

            return user is not null
                ? (user.Username, string.Empty)
                : (null, $"No {role} account found with the email \"{email}\".");
        }
    }
}

using BL.Models;
using BL.Validators;
using DL;

namespace BL.Services
{
    public static class BookService
    {
        public static List<BookRecord> GetAllBooks() => BookRepository.LoadAllBooks();

        public static (List<BookRecord> Books, List<string> Warnings)
            GetBooksByGenre(string genre)
        {
            string path = AppConfig.GetGenreFilePath(genre);
            return BookRepository.LoadBooks(path);
        }

        public static BookRecord? FindBook(string title)
        {
            if (string.IsNullOrWhiteSpace(title)) return null;
            return BookRepository.LoadAllBooks()
                .FirstOrDefault(b =>
                    b.Title.Equals(title, StringComparison.OrdinalIgnoreCase));
        }

        public static OperationResult AddBook(BookRecord book)
        {
            var validation = BookValidator.ValidateBook(book);
            if (!validation.IsValid)
                return OperationResult.Fail(validation.Message);

            string genrePath = AppConfig.GetGenreFilePath(book.Genre);
            var (genreBooks, genreWarnings) = BookRepository.LoadBooks(genrePath);

            if (genreWarnings.Count > 0)
                return OperationResult.Fail(
                    "Could not safely read genre file: " + string.Join("; ", genreWarnings));

            bool exists = genreBooks.Any(b =>
                b.Title.Equals(book.Title, StringComparison.OrdinalIgnoreCase));

            if (exists)
                return OperationResult.Fail(
                    $"A book titled \"{book.Title}\" already exists in {book.Genre}.");

            genreBooks.Add(book);
            var genreResult = BookRepository.SaveBooks(genrePath, genreBooks);
            if (!genreResult.Success) return OperationResult.FromFileResult(genreResult);

            var (allBooks, _) = BookRepository.LoadBooks(AppConfig.MasterBooksPath);
            allBooks.Add(book);
            var masterResult = BookRepository.SaveBooks(AppConfig.MasterBooksPath, allBooks);
            return OperationResult.FromFileResult(masterResult);
        }

        public static OperationResult DeleteBook(string title)
        {
            if (string.IsNullOrWhiteSpace(title))
                return OperationResult.Fail("Book title cannot be empty.");

            bool deletedAny = false;

            string[] genrePaths =
            {
                AppConfig.ActionBooksPath,      // TODO: path to actionBooks.txt
                AppConfig.FictionBooksPath,     // TODO: path to fictionBooks.txt
                AppConfig.NonFictionBooksPath,  // TODO: path to nonFictionBooks.txt
                AppConfig.HorrorBooksPath,      // TODO: path to horrorBooks.txt
                AppConfig.MangaBooksPath        // TODO: path to mangaBooks.txt
            };

            foreach (string path in genrePaths)
            {
                var (books, _) = BookRepository.LoadBooks(path);
                int before = books.Count;
                books.RemoveAll(b =>
                    b.Title.Equals(title, StringComparison.OrdinalIgnoreCase));

                if (books.Count < before)
                {
                    var result = BookRepository.SaveBooks(path, books);
                    if (!result.Success) return OperationResult.FromFileResult(result);
                    deletedAny = true;
                }
            }

            // TODO: Also removes from master index — Data\Books.txt
            var (allBooks, _) = BookRepository.LoadBooks(AppConfig.MasterBooksPath);
            allBooks.RemoveAll(b =>
                b.Title.Equals(title, StringComparison.OrdinalIgnoreCase));
            var masterResult = BookRepository.SaveBooks(AppConfig.MasterBooksPath, allBooks);
            if (!masterResult.Success) return OperationResult.FromFileResult(masterResult);

            return deletedAny
                ? OperationResult.Ok($"Book \"{title}\" deleted successfully.")
                : OperationResult.Fail($"No book found with the title \"{title}\".");
        }

        public static (OperationResult Result, decimal Total) ProcessPurchase(
            string bookTitle, string quantityText)
        {
            var validation = BookValidator.ValidatePurchase(bookTitle, quantityText);
            if (!validation.IsValid)
                return (OperationResult.Fail(validation.Message), 0);

            var book = FindBook(bookTitle);
            if (book is null)
                return (OperationResult.Fail(
                    $"No book found with the title \"{bookTitle}\"."), 0);

            int     qty   = int.Parse(quantityText.Trim());
            decimal total = book.Price * qty;
            return (OperationResult.Ok($"Purchase validated for {qty}\u00d7 \"{book.Title}\"."), total);
        }

        public static void AppendPurchaseLog(
            string username, string bookTitle, int qty, decimal unitPrice, decimal total)
        {
            try
            {
                AppConfig.EnsureDirectoriesExist();
                string line =
                    $"{DateTime.Now:yyyy-MM-dd HH:mm:ss}|{username}|{bookTitle}|{qty}|{unitPrice:F2}|{total:F2}";
                File.AppendAllText(AppConfig.PurchaseLogPath, line + Environment.NewLine);
            }
            catch { /* never let logging crash the app */ }
        }

       
        public static List<(DateTime When, string User, string Title, int Qty, decimal Unit, decimal Total)>
            GetPurchaseHistory()
        {
            var records = new List<(DateTime, string, string, int, decimal, decimal)>();
            try
            {
                AppConfig.EnsureDirectoriesExist();

                if (!File.Exists(AppConfig.PurchaseLogPath)) return records;

                foreach (string line in File.ReadAllLines(AppConfig.PurchaseLogPath))
                {
                    if (string.IsNullOrWhiteSpace(line)) continue;
                    string[] p = line.Split('|');
                    if (p.Length != 6) continue;
                    if (!DateTime.TryParse(p[0],  out var dt))  continue;
                    if (!int.TryParse(p[3],       out int qty)) continue;
                    if (!decimal.TryParse(p[4],   out decimal u)) continue;
                    if (!decimal.TryParse(p[5],   out decimal t)) continue;
                    records.Add((dt, p[1], p[2], qty, u, t));
                }
            }
            catch { /* return whatever was parsed */ }
            return records;
        }
    }
}
